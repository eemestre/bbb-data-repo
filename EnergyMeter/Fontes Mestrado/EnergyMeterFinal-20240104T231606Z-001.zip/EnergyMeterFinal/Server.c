/*
 * Server.c
 *
 *  Created on: Feb 13, 2017
 *      Author: fernando
 */

#include "Server.h"
#include "tcpServer.h"
#include "Flag.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define HANDSHAKE_SIZE 5

static int clientSocket = 0;
static int sent = 0;
static int remaining = 0;
static int progress = 0;
static int packets = 0;
struct ServerData sdata;

static int client_handshake(int clientSocket);


int Server_Open(void)
{
  	int n = 1;
	/***** SERVER SET UP *****/
	/* Open TCP socket */
	printf("Starting server to listen on port %d...\n", PORT);

	clientSocket = getClientSocket();
	printf("Client Socket OK!\n");

	/* Attempt to improve performance */

	if (setsockopt(clientSocket, IPPROTO_TCP, TCP_NODELAY, &n, sizeof(int)) == -1){
		//NOTIFY_ERROR("Error setting TCP_NODELAY socket option.\n");
		return -1;
	}

	return 0;
}

int Server_Handshake(void)
{
	int my_ret = 0;

	int n = client_handshake(clientSocket);

	if(n == -1) {
		printf("Client error.\n");
		close(clientSocket);
	} else if(n == 1) {
		printf("Client Handshake\n");
		my_ret = 1;
	}

	/*restart control variables*/
	sent = 0;
	remaining = 0;
	progress = 0;
	packets = 0;

	return my_ret;
}

int Server_Send(struct ServerData * sd)
{
	int my_ret = 1;
	/*check if transmission is done*/
	if(progress == 0){
		/*reset control variables*/
		sent = 0;
		remaining = sizeof(struct ServerData);
		progress = 1;

		memcpy((void *)&sdata, (void *)sd, sizeof(struct ServerData));
		sdata.hs = 0xFF550AA0;
		sdata.he = 0xA00A55FF;
		sdata.id = ++packets;
	}

	/*Send the remaining bytes*/
	if(progress == 1){
		int n = sendData(clientSocket, (char *)&sdata + sent, remaining);

		if(n == -1) {
			close(clientSocket);
			my_ret = 0;
		}
		else{
			sent += n;
			remaining -= n;

			if(remaining == 0){
				progress = 0;
			}
		}
	}

	return my_ret;
}

static int client_handshake(int clientSocket)
{
    char readBuffer[HANDSHAKE_SIZE + 1];
    int n;

    /* Clear receive buffer */
    memset(readBuffer, '\0', HANDSHAKE_SIZE + 1);

    /* Wait for client handshake */
    n = receiveData(clientSocket, readBuffer, HANDSHAKE_SIZE);

    if(n == HANDSHAKE_SIZE){

		/* Check handshake content */
		if (strcmp(readBuffer, "Ready") != 0)
			return(-1);


		return 1;
    }


    return 0;
}

