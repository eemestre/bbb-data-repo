/*
 * Interface.c
 *
 *  Created on: Aug 4, 2017
 *      Author: fernando
 */

#include "Interface.h"
#include "ssd1306.h"
#include "font.h"
#include <stdio.h>

static char * EnergyMeter_asctime(void);

SSD1306 device(0x3C, SSD1306_128_64);
static int dispOk = 0;
static char msgBuffer[160];

int Interface_Init(void){
    if (device.openDevice("/dev/i2c-1") == 0) {
    	if (device.initDevice() == 0) {
    		dispOk = 1;
    		Clear();
    		return 0;
    	}
    }

    return -1;
}

void ShowMessage(int x, int y, char * msg)
{
    PixelCoordonate px = x, py = y;
    DisplayColor color = DisplayWhiteColor, backgroundColor = DisplayBlackColor;
    Font *currentFont = &font2;
    int vsize = 1, hsize = 1;

	if(dispOk){
		device.getDisplay()->printString(px, py, msg, color, backgroundColor, currentFont, hsize, vsize);
		device.pushDisplay();
	}
}

void Clear()
{
	if(dispOk){
		device.getDisplay()->clearDisplay();
	}
}

void UpdateDisplay(float p, float v, float i, int n)
{
	//sprintf(msgBuffer,"%s", EnergyMeter_asctime());
	//ShowMessage(0, 0, msgBuffer);

	sprintf(msgBuffer, "P:%.3f\nV:%.3f\nI:%.3f\nN = %i", p, v, i, n);
	ShowMessage(0, 32, msgBuffer);

	printf("%s\n", msgBuffer);
}
