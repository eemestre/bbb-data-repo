/*
 * Log.h
 *
 *  Created on: Aug 4, 2017
 *      Author: fernando
 */

#ifndef LOG_H_
#define LOG_H_

#ifdef __cplusplus
extern "C" {
#endif

void Log (char *message);

#ifdef __cplusplus
}
#endif


#endif /* LOG_H_ */
