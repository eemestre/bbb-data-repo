/*
 * Server.h
 *
 *  Created on: Feb 13, 2017
 *      Author: fernando
 */

#ifndef SERVER_H_
#define SERVER_H_

#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif


struct ServerData
{
	int32_t hs;
	float V_rms;
	float I_rms;
	float P_avg;
	float W_avg;
	float Iba_rms;
	float Ibr_rms;
	float Iv_rms;
	float UI_rms;
	float A;
	float Q;
	float Na;
	float Nr;
	float N;
	float V;
	float PF;
	float NF;
	float QF;
	float VF;
	float Psamples[4];
	int32_t id;
	int32_t he;
};

int Server_Open(void);
int Server_Handshake(void);
int Server_Send(struct ServerData * sd);



#ifdef __cplusplus
}
#endif

#endif /* SERVER_H_ */
