/*
 * MetrologyCore.c
 *
 *  Created on: May 21, 2017
 *      Author: fernando
 */

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "MetrologyCore.h"
#include "Goertzel.h"


static int CalculateOffset(float * buffer, int samples, float * output);


static float offsetV = 0;
static float offsetI = 0;



/*DFT and average of DFT*/
#define DFT_POINTS 10
#define DFT_AVG 60

static float dft_v[DFT_POINTS];
static float dft_i[DFT_AVG][DFT_POINTS];
static float dft_i_avg[DFT_POINTS];
static struct Goertzel goertzel;
static int Points = 0;

int MetrologyCore_Init(int points, int fs, int f1)
{
	int status;

    status = Goertzel_Init(&goertzel, points, fs, f1);

    if(status == -1){
    	return -1;
    }

    Points = points;
    Goertzel_EvaluateCoefficients(&goertzel);

    return 0;
}

void MetrologyCore_CopyHarmonics(float * vchannel, float * ichannel)
{
	if(vchannel != NULL){
		memcpy(vchannel, dft_v, sizeof(float) * DFT_POINTS);
	}

	if(ichannel != NULL){
		memcpy(ichannel, dft_i_avg, sizeof(float) * DFT_POINTS);
	}
}

void MetrologyCore_CalculateHarmonics(int samples, float * vchannel, float * ichannel)
{
	int i, j;

	/*
	 * Calculate Mag of first 32 odd harmonics of voltage and current waveforms
	 */
	Goertzel_CalculateOdd(&goertzel, vchannel, dft_v, DFT_POINTS);

	for(i = 0; i < DFT_AVG; i++){
		Goertzel_CalculateOdd(&goertzel, ichannel+(i*Points), dft_i[i], DFT_POINTS);
	}

	/*clear DFT points*/
	for(i = 0; i < DFT_POINTS; i++){
		dft_i_avg[i] = 0;
	}

	/*accumulate DFT points for each cycle*/
	for(i = 0; i < DFT_AVG; i++){
		for(j = 0; j < DFT_POINTS; j++){
			dft_i_avg[j] = dft_i_avg[j] + dft_i[i][j];
		}
	}

	/*Calculate the average of DFT points*/
	for(i = 0; i < DFT_POINTS; i++){
		dft_i_avg[i] = dft_i_avg[i]/(float)DFT_AVG;
	}
}

void MetrologyCore_Scale(int samples, float * vchannel, float * ichannel, float * v_out, float * i_out)
{
	int i;
	/*coefficients to transform voltage and current into rms values*/
	const float Icoeff = (((float)25/((float)24/(float)10)) * ((float)1414213562/(float)1000000000));
	const float Vcoeff = (((float)160/((float)24/(float)10)) * ((float)1414213562/(float)1000000000));

	for(i = 0; i < samples; i++)
	{
		*i_out++ = (float)((*ichannel++) - offsetI) * Icoeff;
		*v_out++ = (float)((*vchannel++) - offsetV) * Vcoeff * ((float)127/(float)125.75);
	}
}

int MetrologyCore_Calibrate(int samples, float * vchannel, float * ichannel){

	int ret;

	/*Voltage offset*/
	ret = CalculateOffset(vchannel, samples, &offsetV);

	if(ret == -1){
		return -1;
	}
	else{
		printf("Offset V: %f\n", offsetV);
	}

	/*Current offset*/
	ret = CalculateOffset(ichannel, samples, &offsetI);

	if(ret == -1){
		return -1;
	}
	else{
		printf("Offset I: %f\n", offsetI);
	}

	return 0;
}


static int CalculateOffset(float * buffer, int samples, float * output)
{
	int i;
	float offset = 0;

	if(buffer == NULL || samples <= 0){
		return -1;
	}

	for(i = 0; i < samples; i++){
		offset = offset + *buffer++;
	}

	*output = offset/(float)samples;

	return 0;
}
