/*
 * DisaggregatonCore.h
 *
 *  Created on: Aug 4, 2017
 *      Author: fernando
 */

#ifndef DISAGGREGATIONCORE_H_
#define DISAGGREGATIONCORE_H_

#ifdef __cplusplus
extern "C" {
#endif


void MysqlEventLog (float pavg, int state, int appclass, unsigned int dt);
void MysqlEnergyLog (float pavg, float energy);
void MysqlPowerLog (float pavg, unsigned int dt);
void MysqlRemoveEvents (void);
void MysqlEndBlock (void);
void ProcessEventList(int appclass);


#ifdef __cplusplus
}
#endif


#endif /* DISAGGREGATONCORE_H_ */
