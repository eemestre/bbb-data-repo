/*
 * CPT.c
 *
 *  Created on: Mar 22, 2017
 *      Author: fernando
 */



// CPT.cpp : Defines the entry point for the console application.
//

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#include "CPT.h"


static double RMS_Evaluate(double input);
static void Phase_Init(struct tPhase * me);
static double MovingAverageFilter_Update(struct tMAF * me, double inputData);
static void MovingAverageFilter_Init(struct tMAF * me, struct tBuffer * buffer, int threshold, double cmp, double min);
static void CPT_Update(struct tCPT * me, struct tPAC * pac, int n);
static void CPT_EvaluateFactors(struct tCPT * me, struct tPAC * pac, int n);
static void CPT_PowerDecomposition(struct tCPT * me, struct tPAC * pac, int n);
static void CPT_CurrentDecomposition(struct tCPT * me, struct tPAC * pac, int n);
static void CPT_UpdateCollectiveValues(struct tCPT * me, struct tPAC * pac, int n);
static void CPT_UpdatePowerAndEnergy(struct tCPT * me, struct tPAC * pac, int n);
static void CPT_UpdateVoltagesAndCurrents(struct tCPT * me, struct tPAC * pac, int n);
static void CPT_Init(struct tCPT * me, struct tPhase * A, struct tPhase * B, struct tPhase * C);


static double RMS_Evaluate(double input)
{
	if (input <= (double)0)
		input = ((double)1/(double)100000);

	return sqrt(input);
}

static void MovingAverageFilter_Init(struct tMAF * me, struct tBuffer * buffer, int threshold, double cmp, double min)
{
	if (me != NULL && buffer != NULL)
	{
		me->Buffer.Data = buffer->Data;
		me->Buffer.Length = buffer->Length;
		me->Accumulator = 0;
		me->MeanValue = 0;
		me->Head = 0;
		me->Threshold_Enabled = threshold;
		me->Threshold_Value = cmp;
		me->Min = min;

		int i;

		for (i = 0; i < me->Buffer.Length; i++)
		{
			me->Buffer.Data[i] = 0;
		}
	}
}

static double MovingAverageFilter_Update(struct tMAF * me, double inputData)
{
	if (me != NULL)
	{
		int head = me->Head;
		double lastValue = me->Buffer.Data[head];

		me->Accumulator = me->Accumulator - lastValue;
		me->Accumulator = me->Accumulator + inputData;

		me->Buffer.Data[head] = inputData;

		head = head + 1;

		if (head >= me->Buffer.Length)
		{
			head = 0;
		}

		me->Head = head;

		if(me->Threshold_Enabled == 1){
			if(me->Accumulator <= me->Threshold_Value){
				me->Accumulator = me->Min;
			}
		}

		me->MeanValue = me->Accumulator / (double)me->Buffer.Length;
		return me->MeanValue;
	}

	return 0;
}

static void Phase_Init(struct tPhase * me)
{
	if (me != NULL)
	{
		me->V_rms = 0;
		me->I_rms = 0;

		me->Integral = 0;
		me->Integral_lastInput = 0;
		me->UnbiasedIntegral = 0;
		me->UnbiasedIntegral_rms = 0;

		me->P_avg = 0;
		me->W_avg = 0;
	}
}

static void CPT_Init(struct tCPT * me, struct tPhase * A, struct tPhase * B, struct tPhase * C)
{
	//if (me != NULL && A != NULL && B != NULL && C != NULL)
	{
		me->Phase[0] = A;
		me->Phase[1] = B;
		me->Phase[2] = C;

		me->Iba_rms = 0;
		me->Iua_rms = 0;
		me->Ibr_rms = 0;
		me->Iur_rms = 0;
		me->Iv_rms = 0;
	}
}

static void CPT_UpdateVoltagesAndCurrents(struct tCPT * me, struct tPAC * pac, int n)
{
	int i;

	for (i = 0; i < n; i++)
	{
		struct tPhase * Phase = me->Phase[i];

		/*RMS value for voltage*/
		Phase->V_pow2 = pac->V[i] * pac->V[i];
		MovingAverageFilter_Update(&Phase->V_maf, Phase->V_pow2);
		Phase->V_rms = RMS_Evaluate(Phase->V_maf.MeanValue);

		/*RMS value for current*/
		Phase->I_pow2 = pac->I[i] * pac->I[i];
		MovingAverageFilter_Update(&Phase->I_maf, Phase->I_pow2);
		Phase->I_rms = RMS_Evaluate(Phase->I_maf.MeanValue);

		/*Voltage Integral*/
		Phase->Integral = Phase->Integral + (TSH / (double)2)*(pac->V[i] + Phase->Integral_lastInput);
		Phase->Integral_lastInput = pac->V[i];
		MovingAverageFilter_Update(&Phase->INT_maf, Phase->Integral);

		/*Unbiased Voltage Integral*/
		Phase->UnbiasedIntegral = Phase->Integral - Phase->INT_maf.MeanValue;
		Phase->UnbiasedIntegral_pow2 = Phase->UnbiasedIntegral * Phase->UnbiasedIntegral;
		MovingAverageFilter_Update(&Phase->UI_maf, Phase->UnbiasedIntegral_pow2);
		Phase->UnbiasedIntegral_rms = RMS_Evaluate(Phase->UI_maf.MeanValue);
	}
}

static void CPT_UpdatePowerAndEnergy(struct tCPT * me, struct tPAC * pac, int n)
{
	int i;

	for (i = 0; i < n; i++)
	{
		struct tPhase * Phase = me->Phase[i];

		Phase->P_inst = pac->V[i] * pac->I[i];

		/*Average of Active Power*/
		Phase->P_avg = MovingAverageFilter_Update(&Phase->P_maf, Phase->P_inst);


		Phase->W_inst = Phase->UnbiasedIntegral * pac->I[i];

		/*Average of Reactive Energy*/
		Phase->W_avg = MovingAverageFilter_Update(&Phase->W_maf, Phase->W_inst);


		/*Average of Reactive Power*/
		Phase->Q = Phase->W_avg *(Phase->V_rms / Phase->UnbiasedIntegral_rms);
	}
}

static void CPT_UpdateCollectiveValues(struct tCPT * me, struct tPAC * pac, int n)
{
	int i;

	me->P_avg = 0;
	me->W_avg = 0;
	me->V_rms = 0;
	me->I_rms = 0;
	me->UI_rms = 0;

	for (i = 0; i < n; i++)
	{
		struct tPhase * Phase = me->Phase[i];

		me->P_avg = me->P_avg + Phase->P_avg;
		me->W_avg = me->W_avg + Phase->W_avg;

		me->V_rms = me->V_rms + Phase->V_pow2;
		me->I_rms = me->I_rms + Phase->I_pow2;
		me->UI_rms = me->UI_rms + Phase->UnbiasedIntegral_pow2;
	}

	me->I_rms = MovingAverageFilter_Update(&me->I_maf, me->I_rms);
	me->V_rms = MovingAverageFilter_Update(&me->V_maf, me->V_rms);
	me->UI_rms = MovingAverageFilter_Update(&me->UI_maf, me->UI_rms);

	me->V_rms = RMS_Evaluate(me->V_rms);
	me->I_rms = RMS_Evaluate(me->I_rms);
	me->UI_rms = RMS_Evaluate(me->UI_rms);
}

static void CPT_CurrentDecomposition(struct tCPT * me, struct tPAC * pac, int n)
{
	int i;

	me->Iv_rms = 0;

	for (i = 0; i < n; i++)
	{
		struct tPhase * Phase = me->Phase[i];

		if (Phase->V_rms != 0)
		{
			Phase->Ia_ActiveCurrent = (Phase->P_avg / (Phase->V_rms * Phase->V_rms)) * pac->V[i];
		}

		if (Phase->UnbiasedIntegral_rms != 0)
		{
			Phase->Ir_ReactiveCurrent = (Phase->W_avg / (Phase->UnbiasedIntegral_rms * Phase->UnbiasedIntegral_rms)) * Phase->UnbiasedIntegral;
		}

		Phase->Iv_VoidCurrent = pac->I[i] - Phase->Ia_ActiveCurrent - Phase->Ir_ReactiveCurrent;
		me->Iv_rms = me->Iv_rms + (Phase->Iv_VoidCurrent * Phase->Iv_VoidCurrent);
	}

	MovingAverageFilter_Update(&me->Iv_maf, me->Iv_rms);
	me->Iv_rms = RMS_Evaluate(me->Iv_maf.MeanValue);


	if (me->V_rms != 0)
	{
		for (i = 0; i < n; i++)
		{
			struct tPhase * Phase = me->Phase[i];
			Phase->Iba_BalancedActiveCurrent = (me->P_avg / (me->V_rms * me->V_rms)) * pac->V[i];
		}
	}

	if (me->UI_rms != 0)
	{
		for (i = 0; i < n; i++)
		{
			struct tPhase * Phase = me->Phase[i];
			Phase->Ibr_BalancedReactiveCurrent = (me->W_avg / (me->UI_rms * me->UI_rms)) * Phase->UnbiasedIntegral;
		}
	}


	/*Balanced current*/
	me->Iba_rms = 0;
	me->Ibr_rms = 0;
	for (i = 0; i < n; i++)
	{
		struct tPhase * Phase = me->Phase[i];

		me->Iba_rms = me->Iba_rms + (Phase->Iba_BalancedActiveCurrent * Phase->Iba_BalancedActiveCurrent);
		me->Ibr_rms = me->Ibr_rms + (Phase->Ibr_BalancedReactiveCurrent * Phase->Ibr_BalancedReactiveCurrent);
	}


	MovingAverageFilter_Update(&me->Iba_maf, me->Iba_rms);
	me->Iba_rms = RMS_Evaluate(me->Iba_maf.MeanValue);
	MovingAverageFilter_Update(&me->Ibr_maf, me->Ibr_rms);
	me->Ibr_rms = RMS_Evaluate(me->Ibr_maf.MeanValue);


	if(n != 1){ /*check if CPT is running only for mono*/

		/*Unbalanced current*/
		for (i = 0; i < n; i++)
		{
			struct tPhase * Phase = me->Phase[i];

			Phase->Iua_UnbalancedActiveCurrent = Phase->Ia_ActiveCurrent - Phase->Iba_BalancedActiveCurrent;

			Phase->Iur_UnbalancedReactiveCurrent = Phase->Ir_ReactiveCurrent - Phase->Ibr_BalancedReactiveCurrent;

			Phase->Iu_UnbalancedCurrent = Phase->Iua_UnbalancedActiveCurrent + Phase->Iur_UnbalancedReactiveCurrent;
		}


		me->Iua_rms = 0;
		me->Iur_rms = 0;

		for (i = 0; i < n; i++)
		{
			struct tPhase * Phase = me->Phase[i];

			me->Iua_rms = me->Iua_rms + (Phase->Iua_UnbalancedActiveCurrent * Phase->Iua_UnbalancedActiveCurrent);
			me->Iur_rms = me->Iur_rms + (Phase->Iur_UnbalancedReactiveCurrent * Phase->Iur_UnbalancedReactiveCurrent);

		}

		MovingAverageFilter_Update(&me->Iua_maf, me->Iua_rms);
		me->Iua_rms = RMS_Evaluate(me->Iua_maf.MeanValue);
		MovingAverageFilter_Update(&me->Iur_maf, me->Iur_rms);
		me->Iur_rms = RMS_Evaluate(me->Iur_maf.MeanValue);
	}
}

static void CPT_PowerDecomposition(struct tCPT * me, struct tPAC * pac, int n)
{

	me->A = me->V_rms * me->I_rms;


	me->Q = me->V_rms * me->Ibr_rms;


	me->Na = me->V_rms * me->Iua_rms;


	me->Nr = me->V_rms * me->Iur_rms;


	me->N = sqrt((me->Na * me->Na) + (me->Nr * me->Nr));


	me->V = me->V_rms * me->Iv_rms;
}

static void CPT_EvaluateFactors(struct tCPT * me, struct tPAC * pac, int n)
{
	if (me->A != 0)
	{
		me->PF = me->P_avg / me->A;
		me->VF = me->V / me->A;
	}

	double P2 = me->P_avg * me->P_avg;
	double Q2 = me->Q * me->Q;
	double N2 = me->N * me->N;

	if ((P2 + Q2 + N2) > 0)
	{
		me->NF = me->N / sqrt(P2 + Q2 + N2);
	}


	if ((P2 + Q2) > 0)
	{
		me->QF = me->Q / sqrt(P2 + Q2);
	}
}

static void CPT_Update(struct tCPT * me, struct tPAC * pac, int n)
{
	CPT_UpdateVoltagesAndCurrents(me, pac, n);
	CPT_UpdatePowerAndEnergy(me, pac, n);
	CPT_UpdateCollectiveValues(me, pac, n);
	CPT_CurrentDecomposition(me, pac, n);
	//CPT_PowerDecomposition(me, pac, n);
	//CPT_EvaluateFactors(me, pac, n);
}


static struct tPAC PAC;

int CPT_Config(struct tCPT_Mono * CPT)
{
	int i;

	for (i = 0; i < 6; i++)
	{
		CPT->PhaseA_Buffers[i].Data = &CPT->PhaseA_Raw[i][0];
		CPT->PhaseA_Buffers[i].Length = sizeof(CPT->PhaseA_Raw[i]) / sizeof(double);
	}

	for (i = 0; i < 8; i++)
	{
		CPT->CPT_Buffers[i].Data = &CPT->CPT_Raw[i][0];
		CPT->CPT_Buffers[i].Length = sizeof(CPT->CPT_Raw[i]) / sizeof(double);
	}

	#define USE_THRESHOLD (1)
	#define THRESHOLD ((double)0)
	#define THR_MIN (0.0001)

	MovingAverageFilter_Init(&CPT->PhaseA.V_maf, &CPT->PhaseA_Buffers[0], USE_THRESHOLD, THRESHOLD, THR_MIN);
	MovingAverageFilter_Init(&CPT->PhaseA.I_maf, &CPT->PhaseA_Buffers[1], USE_THRESHOLD, THRESHOLD, THR_MIN);
	MovingAverageFilter_Init(&CPT->PhaseA.P_maf, &CPT->PhaseA_Buffers[2], 0, 0, 0);
	MovingAverageFilter_Init(&CPT->PhaseA.W_maf, &CPT->PhaseA_Buffers[3], 0, 0, 0);
	MovingAverageFilter_Init(&CPT->PhaseA.UI_maf, &CPT->PhaseA_Buffers[4], USE_THRESHOLD, THRESHOLD, THR_MIN);
	MovingAverageFilter_Init(&CPT->PhaseA.INT_maf, &CPT->PhaseA_Buffers[5], 0, 0, 0);
	Phase_Init(&CPT->PhaseA);

	MovingAverageFilter_Init(&CPT->CPT.Iba_maf, &CPT->CPT_Buffers[0], USE_THRESHOLD, THRESHOLD, THR_MIN);
	MovingAverageFilter_Init(&CPT->CPT.Iua_maf, &CPT->CPT_Buffers[1], USE_THRESHOLD, THRESHOLD, THR_MIN);
	MovingAverageFilter_Init(&CPT->CPT.Ibr_maf, &CPT->CPT_Buffers[2], USE_THRESHOLD, THRESHOLD, THR_MIN);
	MovingAverageFilter_Init(&CPT->CPT.Iur_maf, &CPT->CPT_Buffers[3], USE_THRESHOLD, THRESHOLD, THR_MIN);
	MovingAverageFilter_Init(&CPT->CPT.Iv_maf, &CPT->CPT_Buffers[4], USE_THRESHOLD, THRESHOLD, THR_MIN);
	MovingAverageFilter_Init(&CPT->CPT.I_maf, &CPT->CPT_Buffers[5], USE_THRESHOLD, THRESHOLD, THR_MIN);
	MovingAverageFilter_Init(&CPT->CPT.V_maf, &CPT->CPT_Buffers[6], USE_THRESHOLD, THRESHOLD, THR_MIN);
	MovingAverageFilter_Init(&CPT->CPT.UI_maf, &CPT->CPT_Buffers[7], USE_THRESHOLD, THRESHOLD, THR_MIN);
	CPT_Init(&CPT->CPT, &CPT->PhaseA, NULL, NULL);

	return 0;
}


int CPT_RunMono(struct tCPT_Mono * CPT, float * const pv, float * const pi, int samples, struct tCPT * cpt)
{
	int i;

	float * _pv = pv, * _pi = pi;

	for(i = 0; i < samples; i++)
	{
		PAC.I[0] = (double)*_pi++;
		PAC.V[0] = (double)*_pv++;

		CPT_Update(&CPT->CPT, &PAC, 1);
	}

	CPT_PowerDecomposition(&CPT->CPT, &PAC, 1);
	CPT_EvaluateFactors(&CPT->CPT, &PAC, 1);

	memcpy(cpt, &CPT->CPT, sizeof(struct tCPT));


	return 0;
}

