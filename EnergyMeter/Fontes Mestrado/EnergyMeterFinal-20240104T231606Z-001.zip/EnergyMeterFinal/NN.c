/*
 * NN.c
 *
 *  Created on: Jun 10, 2017
 *      Author: fernando
 */

#include <stdlib.h>
#include <math.h>
#include <float.h>
#include <stdio.h>
#include "NN.h"

#define DBFILE "/home/debian/ADS_PRU/App/DB_KNN.bin"

int LoadDatabase(struct Database * DB, int elements)
{
	if ((DB != NULL) && (elements > 0)){

		FILE *myfile;
		float tmp[21];
		int i;


		for (i = 0; i < 4; i++){
			DB->ATTR_buffer[i] = (float *)malloc(sizeof(float)* elements);

			if (DB->ATTR_buffer[i] == NULL){
				goto alloc_error;
			}
		}

		DB->CLASS_buffer = (int *)malloc(sizeof(int)* elements);

		if (DB->CLASS_buffer == NULL){
			goto alloc_error;
		}

		DB->APPLIANCE_buffer = (int *)malloc(sizeof(int)* elements);

		if (DB->APPLIANCE_buffer == NULL){
			goto alloc_error;
		}


		DB->Elements = elements;


		myfile = fopen(DBFILE, "rb");

		float * P = DB->ATTR_buffer[0];
		float * PF = DB->ATTR_buffer[1];
		float * QF = DB->ATTR_buffer[2];
		float * VF = DB->ATTR_buffer[3];
		int * CLASS = DB->CLASS_buffer;
		int * APP = DB->APPLIANCE_buffer;
		int elements = DB->Elements;

		for (i = 0; i < elements; i++)
		{
			fread(tmp, sizeof(float), 21, myfile);

			*CLASS++ = (int)tmp[0];
			*APP++ = (int)tmp[1];
			*P++ = tmp[2];
			*PF++ = tmp[3];
			*QF++ = tmp[4];
			*VF++ = tmp[5];
		}

		fclose(myfile);

		return 0;
	}

alloc_error:
	return -1;
}

int FindNearestNeighbor(struct Database * DB, struct DBSample * sample)
{
	int i;
	int k = -1;
	float diff[4];
	float sP = sample->P;
	float sPF = sample->PF;
	float sQF = sample->QF;
	float sVF = sample->VF;
	float minimum = FLT_MAX;

	float * P = DB->ATTR_buffer[0];
	float * PF = DB->ATTR_buffer[1];
	float * QF = DB->ATTR_buffer[2];
	float * VF = DB->ATTR_buffer[3];
	int elements = DB->Elements;

	for (i = 0; i < elements; i++)
	{
		diff[0] = *P++ - sP;
		diff[1] = *PF++ - sPF;
		diff[2] = *QF++ - sQF;
		diff[3] = *VF++ - sVF;

		float acc = 0;
		int j;

		for (j = 0; j < 4; j++){
			acc = acc + (diff[j] * diff[j]);
		}

		float dist = sqrt(acc);

		if (dist < minimum){
			minimum = dist;
			k = i;
		}
	}

	return k;
}

