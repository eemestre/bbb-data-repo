/*
 * Flag.h
 *
 *  Created on: Feb 13, 2017
 *      Author: fernando
 */

#ifndef FLAG_H_
#define FLAG_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <pthread.h>

struct flag_control
{
	int thread_flag;
	pthread_mutex_t thread_flag_mutex;
};


void initialize_flag (struct flag_control * me);
void set_thread_flag (struct flag_control * me, int flag_value);

#ifdef __cplusplus
}
#endif

#endif /* FLAG_H_ */
