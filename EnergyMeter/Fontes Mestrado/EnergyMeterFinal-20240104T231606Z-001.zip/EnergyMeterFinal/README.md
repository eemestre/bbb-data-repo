Beaglebone-SSD1306
==================

Beaglebone SSD1306 with i2c