/*
 * NILMCore.c
 *
 *  Created on: Jun 10, 2017
 *      Author: fernando
 */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include "NILMCore.h"
#include "DisaggregationCore.h"
#include "Log.h"

#define WindowLenght 4
#define MAVLenght (WindowLenght)
#define SteadyTime 12
#define DB_SUBTYPES 21

static int NILM_AddAppliance(int Appclass);
static int NILM_RemoveAppliance(int Appclass);
static void NILM_ShowAppliances(void);
static int NILM_RemoveAppliances(void);
static int NILM_GetAppliancesCount(void);
static int NILM_IsOn(int Appclass);
static void NILM_FSM_Refrigerator(int subclass, int evt_type, int * end, int * start);
static void NILM_FSM_Microwave(int subclass, int evt_type, int * end, int * start);
static void NILM_FSM_Common(int subclass, int evt_type, int * end, int * start);

typedef void (*FSM_Function)(int subclass, int evt_type, int * end, int * start);

static FSM_Function FSM_Action[DB_SUBTYPES] = {
		NILM_FSM_Refrigerator,
		NILM_FSM_Microwave,
		NILM_FSM_Common,
		NILM_FSM_Common,
		NILM_FSM_Common,
		NILM_FSM_Common,
		NILM_FSM_Common,
		NILM_FSM_Common,
		NILM_FSM_Common,
		NILM_FSM_Common,
		NILM_FSM_Common,
		NILM_FSM_Common,
		NILM_FSM_Common,
		NILM_FSM_Common,
		NILM_FSM_Common,
		NILM_FSM_Common,
		NILM_FSM_Common,
		NILM_FSM_Common,
		NILM_FSM_Common,
		NILM_FSM_Refrigerator,
		NILM_FSM_Common
};


static const float Pmin = 15;
static const float Pmin2 = 20;
static float MovingWindow[WindowLenght];
static float MovingAverageWindow[MAVLenght];


static int Total;
static int Appliances[100];
static int CanSaveRegistry = 0;
static char msg_log[100];


int NILM_Init(void){
	int i;
	Total = 0;

	for (i = 0; i < (WindowLenght); i++)
	{
	   MovingWindow[i] = 0;
	}

	for (i = 0; i < (MAVLenght); i++)
	{
		MovingAverageWindow[i] = 0;
	}

	NILM_RemoveAppliances();

	return 0;
}


int NILM_Tracker(float Power, unsigned int IterationCounter, unsigned int * dt){

	static float Pacc = 0, lPavg = 0;
	static float PositiveEdge = 0, NegativeEdge = 0;
	static float pbNegativeEdge = 0, pbPositiveEdge = 0;
	static int PositiveEdgeTime = -1, NegativeEdgeTime = -1;
	static int PositiveEdgeDetected = 0, NegativeEdgeDetected = 0;
	static int State = 0, NextState = 0;
	static unsigned int PositiveDT = 0, NegativeDT = 0;
	static int MovingAverageWindowHead = 0;

    float Pp, Pm, Pp2, Pm2;
    float Variance = 0, Pavg = 0, Pold = 0;
    int GoNext = 0;
	int i;
	int EventType = 0;

    lPavg = Pavg;

    /*Update Moving Average Filter*/
    Pacc = Pacc - MovingAverageWindow[MovingAverageWindowHead];
    MovingAverageWindow[MovingAverageWindowHead] = Power;
    Pacc = Pacc + Power;
    Pavg = Pacc / (float)MAVLenght;

    MovingAverageWindowHead++;

    if (MovingAverageWindowHead >= MAVLenght)
    {
        MovingAverageWindowHead = 0;
    }

    /*Calculate the variance of last samples*/
    Variance = 0;

    for (i = 0; i < MAVLenght; i++)
    {
    	float dp = MovingAverageWindow[i] - Pavg;
        Variance = Variance + (dp*dp);
    }

    Variance = (float)sqrt(Variance / (float)MAVLenght);
    Variance = Variance * 1.1f;

    /*Update difference filter*/
	Pold = MovingWindow[0];

	for (i = 0; i < (WindowLenght - 1); i++)
	{
	   MovingWindow[i] = MovingWindow[i + 1];
	}

	/*Insert new value*/
	MovingWindow[WindowLenght - 1] = Pavg;

	/*Calculate difference*/
    Pm = MovingWindow[1] - MovingWindow[0];
    Pm2 = MovingWindow[1] - Pold;

    Pp = MovingWindow[1] - MovingWindow[2];
    Pp2 = MovingWindow[1] - MovingWindow[3];

    Pm = -Pm;
    Pp = -Pp;
    Pm2 = -Pm2;
    Pp2 = -Pp2;

    if (Pm < 0)
        Pm = 0;

    if (Pp < 0)
        Pp = 0;

    if (Pm2 < 0)
        Pm2 = 0;

    if (Pp2 < 0)
        Pp2 = 0;

	/*Process power signal depending on current state*/
	do
	{
	   GoNext = 0;

	   switch(State)
	   {
		   case 0:
               if ((Pp2 > Pmin2) && (Pm2 > Pmin2))
               {
                   NextState = 0;
               }
               else
               {
                   if ((Pp > Pmin) && (Pp2 > Pmin2))
                   {
                       GoNext = 1;
                       NextState = 1;
                   }
                   else if ((Pm > Pmin) && (Pm2 > Pmin2))
                   {
                       GoNext = 1;
                       NextState = 2;
                   }
                   else
                   {
                	   if ((PositiveEdgeDetected == 0) && (NegativeEdgeDetected == 0)){
                		   EventType = -1;
                		   NextState = 0;
                	   }
                	   else{
                		   GoNext = 1;
                		   NextState = 3;
                	   }
                   }
               }
		   break;

		   case 1:

			   if (PositiveEdgeDetected == 0)
			   {
				   EventType = 3;
				   PositiveEdgeDetected = 1;
				   PositiveEdgeTime = 0;
				   PositiveEdge = Pavg;
				   pbPositiveEdge = lPavg;
				   PositiveDT = IterationCounter;
				   sprintf(msg_log,"PositiveEdgeDetected at %i\n", IterationCounter);
				   Log(msg_log);
			   }

			   if (NegativeEdgeDetected == 1)
			   {
                   if (Pavg < NegativeEdge)
                   {
                       PositiveEdgeDetected = 0;
                       sprintf(msg_log,"Discard PositiveEdge at %i\n", IterationCounter);
                       Log(msg_log);
                       if (NegativeEdgeTime > 7)
                       {
                           NegativeEdgeDetected = 0;
                       }
                   }
               }

			   NextState = 3;
		   break;

		   case 2:

			   if (NegativeEdgeDetected == 0)
			   {
				   EventType = 4;
				   NegativeEdgeDetected = 1;
				   NegativeEdgeTime = 0;
				   NegativeEdge = Pavg;
				   pbNegativeEdge = lPavg;
				   NegativeDT = IterationCounter;
				   sprintf(msg_log,"NegativeEdgeDetected at %i\n", IterationCounter);
				   Log(msg_log);
			   }

			   if (PositiveEdgeDetected == 1)
			   {
                   if (Pavg < PositiveEdge)
                   {
                       NegativeEdgeDetected = 0;
                       sprintf(msg_log,"Discard NegativeEdge at %i\n", IterationCounter);
                       Log(msg_log);

                       if (PositiveEdgeTime > 7)
                       {
                           PositiveEdgeDetected = 0;
                       }
                   }
			   }

			   NextState = 3;
		   break;

		   case 3:

			   if (PositiveEdgeDetected == 1)
			   {
				   if ((Power < (Pavg + Variance)) && (Power > (Pavg - Variance)))
				   {
					   PositiveEdgeTime++;
					   //sprintf(msg_log,"--------------------PositiveEdgeTime - %i\n", PositiveEdgeTime);
					   //Log(msg_log);
				   }

				   if (PositiveEdgeTime >= SteadyTime)
				   {
					   PositiveEdgeDetected = 0;

					   //if (fabs(pbPositiveEdge - Pavg) >= 10)
					   {
						   sprintf(msg_log,"--------------------PositiveEdge - steady at %i - pdiff = %f\n", IterationCounter, fabs(pbPositiveEdge - Pavg));
						   Log(msg_log);
						   EventType = 1;
						   *dt = PositiveDT;
					   }
				   }
			   }

			   if (NegativeEdgeDetected == 1)
			   {
				   if ((Power < (Pavg + Variance)) && (Power > (Pavg - Variance)))
				   {
					   NegativeEdgeTime++;
					   //sprintf(msg_log, "--------------------NegativeEdgeTime - %i\n", NegativeEdgeTime);
					   //Log(msg_log);
				   }

				   if (NegativeEdgeTime >= SteadyTime)
				   {
					   NegativeEdgeDetected = 0;

					   //if (fabs(pbNegativeEdge - Pavg) >= 10)
					   {
						   sprintf(msg_log,"--------------------NegativeEdge - steady at %i - pdiff = %f\n", IterationCounter, fabs(pbNegativeEdge - Pavg));
						   Log(msg_log);
						   EventType = 2;
						   *dt = NegativeDT;
					   }
				   }
			   }

			   NextState = 0;
		   break;
	   }

	   State = NextState;
	}while(GoNext == 1);

	if(EventType == 3){
		if(CanSaveRegistry == 0){
			CanSaveRegistry = 1;
		}
	}

	return EventType;
}

void NILM_StateMachine(float pavg, unsigned int evt_time, int appclass, int evt_type)
{
	int status, end = -1, start = -1;

	sprintf(msg_log, "SUBCLASS = %i, DT: %i \n", appclass, evt_time);
	Log((char *)msg_log);

	if(evt_type == 1){

		status = NILM_GetAppliancesCount();

		if(status > 0){
			MysqlEndBlock();
		}

		if(FSM_Action[appclass] != NULL){
			FSM_Action[appclass](appclass, evt_type, &end, &start);
		}

		if(end != -1){
			sprintf(msg_log, "OFF - CLASS = %i, DT: %i \n", end, evt_time);
			Log((char *)msg_log);

			MysqlEventLog(pavg, 2, end, evt_time);
			ProcessEventList(end);
		}

		if(start != -1){
			sprintf(msg_log, "ON - CLASS = %i, DT: %i \n", start, evt_time);
			Log((char *)msg_log);

			MysqlEventLog(pavg, 1, start, evt_time);
		}
	}
	else if(evt_type == 2){

		if(FSM_Action[appclass] != NULL){
			FSM_Action[appclass](appclass, evt_type, &end, &start);
		}

		if(end != -1){
			sprintf(msg_log, "OFF - CLASS = %i, DT: %i \n", end, evt_time);
			Log((char *)msg_log);

			MysqlEndBlock();
			ProcessEventList(end);
			MysqlEventLog(pavg, 2, end, evt_time);
		}
	}

	NILM_ShowAppliances();

	if(evt_type == 2 && (NILM_IsOn(appclass) == 0)){
		CanSaveRegistry = 0;
	}
}

int NILM_GroundTruth(float pavg)
{
	static int PzeroCounter = 0;
	int status, i;

	if(pavg <= 20){

		/*if(PzeroCounter == 0){
			Log((char *)"Ground Truth...\n");
		}*/

		if(PzeroCounter >= 20){
			status = NILM_GetAppliancesCount();

			if(status > 0){
				Log((char *)"Remove all...\n");
				MysqlEndBlock();

				for (i = 0; i < 20; i++){
				   status = NILM_IsOn(i);

				   if(status == 1){
					   ProcessEventList(i);
				   }
				}

				MysqlRemoveEvents();
				NILM_RemoveAppliances();
				CanSaveRegistry = 0;
				PzeroCounter = 0;
				return 0;
			}
		}
		else{
			PzeroCounter++;
		}
	}
	else{
		PzeroCounter = 0;
	}

	return 1;
}

void NILM_UpdateEnergy(float pavg, unsigned int tstamp)
{
	static int seconds = 0;
	static float power_avg_min = 0;
    int status;

	/*Update energy consumption*/
	power_avg_min += pavg;
	seconds++;

	if(seconds >= 60){
		power_avg_min = power_avg_min / (float)60;
		MysqlEnergyLog(power_avg_min, ((power_avg_min / (float)60) / (float)1000));/* /60 -> kwh*/
		power_avg_min = 0;
		seconds = 0;
	}

	/*Check if there are appliances to monitoring*/
	status = NILM_GetAppliancesCount();

	if((CanSaveRegistry == 1)  || (status > 0)){
		/*store new sample to create a block*/
		MysqlPowerLog (pavg, tstamp);
	}
}


static void NILM_FSM_Refrigerator(int subclass, int evt_type, int * end, int * start)
{
	int status;

	if(evt_type == 1){
		switch(subclass)
		{
			case 0:
				status = NILM_IsOn(0);

				if(status >= 1){
					NILM_RemoveAppliance(0);
					*end = 0;

					status = NILM_AddAppliance(19);

					if(status > 0){
						*start = 19;
					}
				}
				else{

					status = NILM_IsOn(19);

					if(status >= 1){
						NILM_RemoveAppliance(19);
						*end = 19;
					}

					status = NILM_AddAppliance(0);

					if(status > 0){
						*start = 0;
					}
				}

			break;

			case 19:
				status = NILM_IsOn(0);

				if(status >= 1){
					NILM_RemoveAppliance(0);
					*end = 0;
				}

				status = NILM_AddAppliance(subclass);

				if(status > 0){
					*start = subclass;
				}
			break;
		}
	}
	else{
		status = NILM_RemoveAppliance(subclass);

		if(status == 0){
			*end = subclass;
		}
	}
}

static void NILM_FSM_Microwave(int subclass, int evt_type, int * end, int * start)
{
	int status;

	if(evt_type == 1){

		status = NILM_IsOn(subclass);

		if(status == 0){
			status = NILM_AddAppliance(subclass);

			if(status > 0){
				*start = subclass;
			}
		}
	}
	else{
		status = NILM_RemoveAppliance(subclass);

		if(status == 0){
			*end = subclass;
		}
	}
}

static void NILM_FSM_Common(int subclass, int evt_type, int * end, int * start)
{
	int status;

	if(evt_type == 1){
		status = NILM_IsOn(subclass);

		if(status == 0){
			status = NILM_AddAppliance(subclass);

			if(status > 0){
				*start = subclass;
			}
		}
	}
	else{
		status = NILM_RemoveAppliance(subclass);

		if(status == 0){
			*end = subclass;
		}
	}
}

static int NILM_AddAppliance(int Appclass)
{
	Appliances[Appclass]++;
	Total++;

	sprintf(msg_log, "Adding appliance into class %i - Total: %i.\n", Appclass, Appliances[Appclass]);
	Log(msg_log);

	return Appliances[Appclass];
}

static int NILM_RemoveAppliance(int Appclass)
{
	if(Appliances[Appclass] > 0){
		Appliances[Appclass]--;
		Total--;
		sprintf(msg_log, "Removing appliance from class %i - Total: %i\n", Appclass, Appliances[Appclass]);
		return 0;
	}
	else{
		sprintf(msg_log, "There are no appliances to remove from class %i.\n", Appclass);
	}

	Log(msg_log);

	return -1;
}

static void NILM_ShowAppliances(void)
{
	int i = 0;

	for(i = 0; i < DB_SUBTYPES; i++){
		printf("[%i] = %i\n", i, Appliances[i]);
	}
}

static int NILM_RemoveAppliances(void)
{
	if(Total > 0){

		int i;

		for (i = 0; i < DB_SUBTYPES; i++)
		{
		   Appliances[i] = 0;
		}

		Total = 0;

		return 0;
	}

	return -1;
}

static int NILM_GetAppliancesCount(void)
{
	return Total;
}

static int NILM_IsOn(int Appclass)
{
	if(Appliances[Appclass] > 0){
		return 1;
	}

	return 0;
}
