/*
 * Interface.h
 *
 *  Created on: Aug 4, 2017
 *      Author: fernando
 */

#ifndef INTERFACE_H_
#define INTERFACE_H_

#ifdef __cplusplus
extern "C" {
#endif

int Interface_Init(void);
void Clear();
void ShowMessage(int x, int y, char * msg);
void UpdateDisplay(float p, float v, float i, int n);

#ifdef __cplusplus
}
#endif

#endif /* INTERFACE_H_ */
