/*
 * NN.h
 *
 *  Created on: Jun 10, 2017
 *      Author: fernando
 */

#ifndef NN_H_
#define NN_H_

#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

struct DBSample{
	float P;
	float PF;
	float QF;
	float VF;
};

struct Database
{
	float * ATTR_buffer[4];
	int * CLASS_buffer;
	int * APPLIANCE_buffer;
	int Elements;
};


int LoadDatabase(struct Database * DB, int elements);
int FindNearestNeighbor(struct Database * DB, struct DBSample * sample);


#ifdef __cplusplus
}
#endif

#endif /* NN_H_ */
