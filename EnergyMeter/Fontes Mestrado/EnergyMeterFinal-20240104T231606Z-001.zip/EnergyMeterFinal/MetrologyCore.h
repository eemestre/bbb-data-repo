/*
 * MetrologyCore.h
 *
 *  Created on: May 21, 2017
 *      Author: fernando
 */

#ifndef METROLOGYCORE_H_
#define METROLOGYCORE_H_

#ifdef __cplusplus
extern "C" {
#endif

int MetrologyCore_Init(int points, int fs, int f1);
int MetrologyCore_Calibrate(int samples, float * vchannel, float * ichannel);
void MetrologyCore_Scale(int samples, float * vchannel, float * ichannel, float * v_out, float * i_out);
void MetrologyCore_CalculateHarmonics(int samples, float * vchannel, float * ichannel);
void MetrologyCore_CopyHarmonics(float * vchannel, float * ichannel);


#ifdef __cplusplus
}
#endif

#endif /* METROLOGYCORE_H_ */
