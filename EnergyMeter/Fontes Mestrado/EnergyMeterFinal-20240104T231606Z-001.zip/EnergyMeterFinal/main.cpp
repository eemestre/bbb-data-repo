
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <pthread.h>
#include <time.h>
#include <string.h>
#include <fcntl.h>
#include <math.h>
#include <sys/mman.h>
#include "Mem.h"
#include "DAQ.h"

#include "Server.h"
#include "Flag.h"
#include "CPT.h"
#include "Goertzel.h"
#include "tcpServer.h"
#include "MetrologyCore.h"
#include "AnalogCore.h"
#include "NILMCore.h"
#include "NN.h"
#include "DisaggregationCore.h"
#include "Waveform.h"
#include "Log.h"
#include "Interface.h"

#define CPT_STEPS 4
#define HANDSHAKE_SIZE 5
#define GOERTZEL_POINTS 256
#define NOTIFY_ERROR(MSG) fprintf(stderr, "EnergyMeter: %s", MSG)
#define EVT_SAMPLES 15*256

enum EnergyMeterState{
	STATE_SETUP = 0,
	STATE_GET_SAMPLES,
	STATE_PROCESS_SAMPLES,
	STATE_STABLISH_CONNECTION,
	STATE_TRANSMIT,
	STATE_UPDATE_DISPLAY,
	STATE_CALIBRATE,
	STATE_SAVE_TO_FILE,
	STATE_END
};


#define DB_DEFAULT 1
#if DB_DEFAULT == 0
	#define DB_COLUMNS (15)
#else
	#define DB_COLUMNS (15+4)
#endif

static char const * const ClassName[] = {
	"Classe 1: Geladeira.",
	"Classe 2: Micro-ondas.",
	"Classe 3: Purificador de água.",
	"Classe 4: Notebook.",
	"Classe 5: Aparelho de som.",
	"Classe 6: Televisão LED.",
	"Classe 7: Liquidificador.",
	"Classe 8: Televisão LCD.",
	"Classe 9: Máquina de lavar roupas.",
	"Classe 10: Secador de cabelos.",
	"Classe 11: Lâmpada Fluorescente.",
	"Classe 12: Computador Desktop.",
	"Classe 13: Forno Elétrico.",
	"Classe 14: Monitor LCD-LED-Tubo.",
	"Classe 15: Lâmpada LED.",
	"Classe 16: Ferro de passar.",
	"Classe 17: Lâmpada Incandescente.",
	"Classe 18: Fritadeira Elétrica.",
	"Classe 19: Ar condicionado.",
	"Classe 20: Degelo.",
	"Classe 21: Ar condicionado.",
};

struct VI_SignatureEvent{
	float V_Waveform[EVT_SAMPLES];
	float I_Waveform[EVT_SAMPLES];
	unsigned int Samples;
	unsigned int type;
	unsigned int time;
	float Power;
};

static void CopyCPTData(struct tCPT * cpt, struct ServerData * data);
static int CopyToFile(float * db, int pos);
static int ProcessEvent(int event, struct VI_Signature * in, struct DBSample * sample);

static void SaveP (char * fname, float * wf, int len)
{
	FILE *file;
	static char fn[30];

	sprintf(fn,"%s.bin", fname);

	file = fopen(fn, "a");

	if (file == NULL) {
		return;
	}
	else
	{
		fwrite(wf, sizeof(float), len, file);
		fclose(file);
		//printf("Arquivo gravado: %s\n", fn);
	}
}

static struct tCPT_Mono CPT_KNN;
static struct tCPT CPTdata_KNN;
static struct VI_SignatureEvent LastState;
static struct VI_SignatureEvent EventDiff;

int main(int argc, const char **argv)
{
	int FirstExecution = 1;
	unsigned int IterationCounter = 0; /*Counter used for mark time of event during nilm execution*/
	float lPower = 0; /*It stores the last value of active power*/
	float Phistory[CPT_STEPS];
	float avh_hist = 0;
	float EvtPower = 0;

	/*CPT data struct*/
	struct tCPT CPTdata;
	struct tCPT_Mono CPT;

	struct tAnalogCoreSetup AnalogCore;
	float * volatile pt_Isamples;
	float * volatile pt_Vsamples;
	float V_samples[SAMPLES*2];
	float I_samples[SAMPLES*2];

    /*Variables used in communcation*/
    struct ServerData sdata;
    int clientConnected = 0;

    /*Variables used to check if there is a missed packet*/
    unsigned int lastEventN = 0;
    unsigned int EventN;

    /*Variables used to calibrate V and I channels*/
    int calibration_done = 0;

    /*Determine number of samples stored at db file*/
    unsigned int db_idx = 0;
    float db[DB_COLUMNS];

    /*Knn Db*/
    struct Database DB;
    unsigned int KNN_DB_Samples = 0;

    /*Variables used to control flow and operation mode*/
    int op_mode = 0;
    unsigned int MaxSamples = 0;
    int stop_daq = 1;
    enum EnergyMeterState state = STATE_SETUP;
    enum EnergyMeterState nextState = STATE_SETUP;
    int code = EXIT_FAILURE;

    /*temporary - it shoudn't be used to store value for more than one iteration*/
    int status;

	unsigned int event_time;
    volatile int processNextWave = 0;
    int stable_state = 0;

    /*if there are arguments in command line convert it to seconds*/
    if(argc == 4){
    	unsigned int hr = atoi(argv[1]);
    	unsigned int min = atoi(argv[2]);

    	if(hr >= 48){
    		hr = 48;
    	}

    	if(min>=60){
    		min = 60;
    	}

    	MaxSamples = (hr*3600)+(min*60);
    	printf("Total: %i\n", MaxSamples);
    	op_mode = 1;
    }
    else if(argc == 3){
    	unsigned int cmd = atoi(argv[1]);

    	if(cmd == 1){
    		op_mode = 2;

    		KNN_DB_Samples = atoi(argv[2]);
    		printf("KNN DB: %i\n", KNN_DB_Samples);
    	}
    }

    Log((char *)"Starting...\n");

    /* PRU code only works if executed as root */
    if (getuid() != 0) {
    	NOTIFY_ERROR("This program needs to run as root.\n");
        code = -1;
        goto exit_failure;
    }

    /*try to change scheduler policy*/
    {
		struct sched_param sched_param;
		sched_param.sched_priority = 1;

		/* enable real time fifo scheduling */
		if(sched_setscheduler(getpid(), SCHED_RR, &sched_param)==-1){
			NOTIFY_ERROR("sched_setscheduler failed");
		   code = -1;
		   goto exit_failure;
		}
    }

    /*Lock memory to ensure no swapping is done.*/
    if(mlockall(MCL_FUTURE|MCL_CURRENT)){
    	NOTIFY_ERROR("Failed to lock memory\n");
    	code = -1;
    	goto exit_failure;
    }

    status = Interface_Init();

    if (status != 0) {
    	NOTIFY_ERROR("Problem to open display device\n");
    }

    status = AnalogCore_Init();

    if(status != 0) {
    	NOTIFY_ERROR("Error analog core.\n");
    	code = -1;
    	goto exit_failure_ram;
    }

    if(op_mode == 0){
    	status = Server_Open();

		if (status == -1){
			code = -1;
			goto exit_failure_server;
		}
    }

    status = MetrologyCore_Init(GOERTZEL_POINTS, FS, 60);

    if(status == -1){
    	NOTIFY_ERROR("MetrologyCore error.\n");
        code = -1;
        goto exit_failure;
    }

    CPT_Config(&CPT);

    if(op_mode == 2){

        status = NILM_Init();

        if(status == -1){
    		NOTIFY_ERROR("NILM error.\n");
    		code = -1;
    		goto exit_failure;
    	}

    	LoadDatabase(&DB, KNN_DB_Samples);
    	MysqlRemoveEvents();
    }

	while(stop_daq)
	{
		switch(state)
		{
			case STATE_SETUP:

				Clear(); /*Clear Display*/

				/*Setup PRU before start daq*/
			    status = AnalogCore_Setup(&AnalogCore);

			    if(status != 0) {
			    	NOTIFY_ERROR("Error setting up PRU.\n");
			    	code = -1;
			        goto exit_failure_pru;
			    }

				nextState = STATE_GET_SAMPLES;
			break;

			case STATE_GET_SAMPLES:
				EventN = AnalogCore_GetSamples(&AnalogCore);

				/*verify if application lost packets*/
				if((EventN - lastEventN) > 1){
					if(lastEventN != 0){
						NOTIFY_ERROR("\nPRU events: perdeu pacote!!!\n");
						Log((char *)"Perdeu amostra\n");
					}
				}

				/*update packets number*/
				lastEventN = EventN;

				if(AnalogCore.bank == 1){
					pt_Isamples = I_samples;
					pt_Vsamples = V_samples;
				}
				else{
					pt_Isamples = I_samples + SAMPLES;
					pt_Vsamples = V_samples + SAMPLES;
				}

				/*Check if calibration was done*/
				if(calibration_done == 0){
					nextState = STATE_CALIBRATE;
				}
				else{
					nextState = STATE_PROCESS_SAMPLES;
				}

			break;

			case STATE_PROCESS_SAMPLES:

				if(AnalogCore.v_channel != NULL && AnalogCore.i_channel != NULL){

					/* Remove offset of each sample and multiply the result by rms conversion coefficient.
					 * Evaluate average of harmonics.
					 * Run CPT for all samples.
					 */
					MetrologyCore_Scale(SAMPLES, AnalogCore.v_channel, AnalogCore.i_channel, pt_Vsamples, pt_Isamples);
					MetrologyCore_CalculateHarmonics(SAMPLES, pt_Vsamples, pt_Isamples);

					if((FirstExecution == 1) || (op_mode < 2)){

						CPT_RunMono(&CPT, (float * const)pt_Vsamples, (float * const)pt_Isamples, SAMPLES, &CPTdata);

						if(FirstExecution != 0){
							//memset(LastState.I_Waveform, 0, EVT_SAMPLES*sizeof(float));
							memcpy(LastState.I_Waveform, pt_Isamples, EVT_SAMPLES*sizeof(float));
							memcpy(LastState.V_Waveform, pt_Vsamples, EVT_SAMPLES*sizeof(float));
							FirstExecution = 0;

							if(CPTdata.P_avg < 0){
								lPower = (float)CPTdata.P_avg;
							}
							else{
								lPower = 0;
							}
						}
						else{
							/*Initial value of active power*/
							if(CPTdata.P_avg < 0){
								CPTdata.P_avg = (double)lPower;
							}
							else{
								lPower = (float)CPTdata.P_avg;
							}
						}
					}
					else{
						int i, nilm_status;
						struct VI_Signature in;

						in.V_Waveform = pt_Vsamples;
						in.I_Waveform = pt_Isamples;
						in.Samples = SAMPLES/CPT_STEPS;

						if(processNextWave > 0){
							struct DBSample sample;
							status = ProcessEvent(processNextWave, &in, &sample);

							if(status == 0){
								int k = FindNearestNeighbor(&DB, &sample);
								int appclass = DB.CLASS_buffer[k]-1;

								NILM_StateMachine((float)CPTdata_KNN.P_avg, event_time, appclass, processNextWave);

								EvtPower = avh_hist;

								/*update last event waveform*/
								memcpy(LastState.I_Waveform, in.I_Waveform, in.Samples*sizeof(float));
								memcpy(LastState.V_Waveform, in.V_Waveform, in.Samples*sizeof(float));
							}
							processNextWave = 0;
						}

						avh_hist = 0;

						for(i = 0; i < CPT_STEPS; i++){
							CPT_RunMono(&CPT, (float * const)in.V_Waveform, (float * const)in.I_Waveform, in.Samples, &CPTdata);

							if(CPTdata.P_avg < 0){
								CPTdata.P_avg = lPower;
							}

							/*Update pavg tap and tracker power consumption*/
							Phistory[i] = (float)CPTdata.P_avg;

							in.V_Waveform += (SAMPLES/CPT_STEPS);
							in.I_Waveform += (SAMPLES/CPT_STEPS);

							/*update last Pavg*/
							lPower = Phistory[i];
							avh_hist = avh_hist + Phistory[i];
						} //END FOR

						/*Update mean active power*/
						avh_hist = avh_hist/CPT_STEPS;

						for(i = 0; i < CPT_STEPS; i++){
							nilm_status = NILM_Tracker(Phistory[i], IterationCounter, &event_time);

							if(nilm_status == 1 || nilm_status == 2){
								processNextWave = nilm_status;
								stable_state = 0;
							}
							else{
								if(nilm_status == -1){
									stable_state++;
								}
								else{
									stable_state = 0;
								}
							}
							/*
							else if(nilm == 3){
								Log((char *)"Rising Edge detected..\n");
							}
							else if(nilm == 4){
								Log((char *)"Falling Edge detected..\n");
							}*/

							IterationCounter++;
						}

						if(stable_state >= 40){
							stable_state = 0;

							if(fabs(EvtPower - avh_hist) > 50){
								memcpy(LastState.I_Waveform, pt_Isamples, EVT_SAMPLES*sizeof(float));
								memcpy(LastState.V_Waveform, pt_Vsamples, EVT_SAMPLES*sizeof(float));
							}
						}

						NILM_UpdateEnergy(avh_hist, IterationCounter);

						status = NILM_GroundTruth(avh_hist);

						if(status == 0){
							/*set default waveform - all events were removed*/
							//memset(LastState.I_Waveform, 0, EVT_SAMPLES*sizeof(float));
							memcpy(LastState.I_Waveform, pt_Isamples, EVT_SAMPLES*sizeof(float));
							memcpy(LastState.V_Waveform, pt_Vsamples, EVT_SAMPLES*sizeof(float));
							//MetrologyCore_Calibrate(SAMPLES, pt_Vsamples, pt_Isamples);
						}

						SaveP((char *)"Pavg", Phistory, 4);

					}//ELSE <--> !FirstExecution
				}//IF BUFFERS != NULL

				if(op_mode == 0){
					/*Check if client is connected*/
					if(clientConnected == 0){
						nextState = STATE_STABLISH_CONNECTION; /*Go to next state and establish connection*/
					}
					else{
						nextState = STATE_TRANSMIT; /*Go to next state and send acquired data*/
					}
				}
				else{
					if(op_mode == 1){
						nextState = STATE_SAVE_TO_FILE; /*Write data to file*/
					}
					else{
						nextState = STATE_UPDATE_DISPLAY;
					}
				}
			break;

			case STATE_STABLISH_CONNECTION:
				if(clientConnected == 0){
					clientConnected = Server_Handshake();
				}
				else{
					nextState = STATE_TRANSMIT;
				}
			break;

			case STATE_TRANSMIT:
				/*check if there is a client connected*/
				if(clientConnected == 1){
					/*Copy data - CPT, DFT and waveform*/
					CopyCPTData(&CPTdata, &sdata);
					for(int i = 0; i < CPT_STEPS; i++){
						sdata.Psamples[i] = Phistory[i];
					}
					clientConnected = Server_Send(&sdata);
				}
				nextState = STATE_UPDATE_DISPLAY;
			break;

			case STATE_UPDATE_DISPLAY:
				UpdateDisplay((float)CPTdata.P_avg, (float)CPTdata.V_rms, (float)CPTdata.I_rms, 0);
				nextState = STATE_GET_SAMPLES;
			break;

			case STATE_CALIBRATE:
				/*Calculate offset values for voltage and current channels*/
				status = MetrologyCore_Calibrate(SAMPLES, AnalogCore.v_channel, AnalogCore.i_channel);

				if(status == -1){
					NOTIFY_ERROR("Erro: CalculateOffset\n");
				}
				else{
					calibration_done = 1;
					SaveWaveform((char *)"offsetI", AnalogCore.i_channel, SAMPLES);
					SaveWaveform((char *)"offsetV", AnalogCore.v_channel, SAMPLES);
				}
				nextState = STATE_GET_SAMPLES;
			break;

			case STATE_SAVE_TO_FILE:
				if(db_idx >= MaxSamples){
					nextState = STATE_END;
				}
				else{
					db[0] = (float)CPTdata.P_avg;
					db[1] = (float)CPTdata.PF;
					db[2] = (float)CPTdata.QF;
					db[3] = (float)CPTdata.VF;
					db[4] = (float)CPTdata.I_rms;

					MetrologyCore_CopyHarmonics(NULL, &db[5]);

					#if DB_DEFAULT == 1
						db[15] = (float)CPTdata.V_rms;
						db[16] = (float)CPTdata.A;
						db[17] = (float)CPTdata.V;
						db[18] = (float)CPTdata.Q;
					#endif

					/*Write new sample to file*/
					if(CopyToFile(db, db_idx) == 0){
						db_idx++;
					}

					UpdateDisplay((float)CPTdata.P_avg, (float)CPTdata.V_rms, (float)CPTdata.I_rms, db_idx);
					nextState = STATE_GET_SAMPLES;
				}
			break;

			case STATE_END:
				nextState = STATE_END;
				Clear();
				ShowMessage(0, 0, (char *)"Finalizado.");
				stop_daq = 0;
				SaveWaveform((char *)"V", pt_Vsamples, SAMPLES);
				SaveWaveform((char *)"I", pt_Isamples, SAMPLES);
				Log((char *)"Finalizando operação...\n");
			break;
		}

		state = nextState;
		sched_yield();
	}

    printf("Exiting.\n");

    code = EXIT_SUCCESS;

exit_failure_pru:
    DAQ_Stop();
exit_failure_server:
exit_failure_ram:
    AnalogCore_Deinit();
exit_failure:
	if(code != EXIT_SUCCESS){
		exit(code);
	}

    return(code);
}

static int ProcessEvent(int event, struct VI_Signature * in, struct DBSample * sample)
{
	struct VI_Signature prior, current, out;
	static char parambuffer[100];

	prior.I_Waveform = LastState.I_Waveform;
	prior.V_Waveform = LastState.V_Waveform;
	prior.Samples = EVT_SAMPLES;
	current.I_Waveform = in->I_Waveform;
	current.V_Waveform = in->V_Waveform;
	current.Samples = EVT_SAMPLES;
	out.I_Waveform = EventDiff.I_Waveform;
	out.V_Waveform = EventDiff.V_Waveform;
	out.Samples = EVT_SAMPLES - (2*256);

	if(event == 1){
		WaveformDiff(&prior, &current, &out, 2, 0);
	}
	else if(event == 2){
		WaveformDiff(&current, &prior, &out, 2, 0);
	}

	CPT_Config(&CPT_KNN);
	CPT_RunMono(&CPT_KNN, (float * const)out.V_Waveform, (float * const)out.I_Waveform, out.Samples, &CPTdata_KNN);

	if(CPTdata_KNN.P_avg > 0){
		sprintf(parambuffer, "KNN: P = %.4f PF = %.4f QF = %.4f VF = %.4f\r\n", (float)CPTdata_KNN.P_avg, (float)CPTdata_KNN.PF, (float)CPTdata_KNN.QF, (float)CPTdata_KNN.VF);
		Log(parambuffer);

		sample->P = (float)CPTdata_KNN.P_avg/(float)2000; /*P.U*/
		sample->PF = (float)CPTdata_KNN.PF;
		sample->QF = (float)CPTdata_KNN.QF;
		sample->VF = (float)CPTdata_KNN.VF;
		return 0;
	}
	else{
		Log((char *)"CPT Pavg negative after event...\n");
	}

	return -1;
}

static void CopyCPTData(struct tCPT * cpt, struct ServerData * data)
{
	data->V_rms = (float)cpt->V_rms;
	data->I_rms = (float)cpt->I_rms;
	data->UI_rms = (float)cpt->UI_rms;
	data->Iba_rms = (float)cpt->Iba_rms;
	data->Ibr_rms = (float)cpt->Ibr_rms;
	data->Iv_rms = (float)cpt->Iv_rms;
	data->P_avg = (float)cpt->P_avg;
	data->W_avg = (float)cpt->W_avg;
	data->A = (float)cpt->A;
	data->Q = (float)cpt->Q;
	data->NF = (float)cpt->NF;
	data->Na = (float)cpt->Na;
	data->N = (float)cpt->N;
	data->V = (float)cpt->V;
	data->PF = (float)cpt->PF;
	data->NF = (float)cpt->NF;
	data->QF = (float)cpt->QF;
	data->VF = (float)cpt->VF;
}

static int CopyToFile(float * db, int pos)
{
	int ret = -1;
	int pfile = open("/home/debian/ADS_PRU/App/DB.bin", O_WRONLY);

	if(pfile > 0){

		long size = sizeof(float)*DB_COLUMNS;
		long offset = pos*size;
		long status = lseek(pfile, offset, SEEK_SET);

		if(status == offset){
			status = write(pfile, db, size);

			if(status != (size)){
				NOTIFY_ERROR("Cannot write to db file!\n");
			}
			else{
				ret = 0;
			}
		}
		else{
			NOTIFY_ERROR("Cannot move db file pointer!\n");
		}
	}
	else{
		NOTIFY_ERROR("Cannot open db file!\n");
	}

	close(pfile);
	return ret;
}
