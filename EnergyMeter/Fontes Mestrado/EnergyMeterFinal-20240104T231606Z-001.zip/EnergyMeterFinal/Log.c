/*
 * Log.c
 *
 *  Created on: Aug 4, 2017
 *      Author: fernando
 */

#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <string.h>
#include <stdio.h>

#include "Log.h"

#define LOGFILE "/home/debian/ADS_PRU/App/log.txt"

static char *EnergyMeter_asctime(void);

static char msgBuffer[160];
static int LogCreated = 0;

void Log (char *message)
{
	FILE *file;

	if (LogCreated == 0) {
		//printf("Criando arquivo de log\n");
		file = fopen(LOGFILE, "w");
		LogCreated = 1;
	}
	else{
		//printf("Abrindo arquivo de log\n");
		file = fopen(LOGFILE, "a");
	}

	if (file == NULL) {
		if (LogCreated)
			LogCreated = 0;
		return;
	}
	else
	{
		//printf("Gravando arquivo de log\n");

		sprintf(msgBuffer,"%s: ", EnergyMeter_asctime());
		fputs(msgBuffer, file);
		fputs(message, file);
		//printf("Fechando arquivo de log\n");
		fclose(file);

		printf("%s: %s\r\n", msgBuffer, message);
	}
}


static char *EnergyMeter_asctime(void)
{
	static char wday_name[7][4] = {
	    "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"
	};

	static char mon_name[12][4] = {
	    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
	    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
	};

	static char result[26];


	/* Get the current time. */
	static time_t curtime;

	time(&curtime);

	/* Convert it to local time representation. */
	struct tm *timeptr = localtime (&curtime);

    sprintf(result, "%.3s%.3s %3d %d %.2d %.2d %.2d",
        wday_name[timeptr->tm_wday],
        mon_name[timeptr->tm_mon],
        timeptr->tm_mday,
        1900 + timeptr->tm_year,
        timeptr->tm_hour,
        timeptr->tm_min,
        timeptr->tm_sec);

    return result;
}
