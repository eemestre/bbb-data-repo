/*
 * NILMCore.h
 *
 *  Created on: Jun 10, 2017
 *      Author: fernando
 */

#ifndef NILMCORE_H_
#define NILMCORE_H_

#ifdef __cplusplus
extern "C" {
#endif

int NILM_Init(void);
int NILM_Tracker(float Power, unsigned int IterationCounter, unsigned int * dt);
void NILM_StateMachine(float pavg, unsigned int evt_time, int appclass, int evt_type);

/*These functions need to be called every second - one shot / second*/
int NILM_GroundTruth(float pavg);
void NILM_UpdateEnergy(float pavg, unsigned int tstamp);
#ifdef __cplusplus
}
#endif

#endif /* NILMCORE_H_ */
