/*
 * DisaggregatonCore.c
 *
 *  Created on: Aug 4, 2017
 *      Author: fernando
 */

#include <stdlib.h>
#include "DisaggregationCore.h"
#include <mysql/mysql.h>

void MysqlEventLog (float pavg, int state, int appclass, unsigned int dt)
{
	MYSQL *con = mysql_init(NULL);

	if(con != NULL){

		if (mysql_real_connect(con, "localhost", "root", "090461", "energymeter", 0, NULL, 0) != NULL)
		{
			// Set out insert query as the MySQL statement
			static char query[1000];

			if(state == 1){
				printf("Adding class\n");
				sprintf(query, "insert into AppOn(Class) values (%i);", appclass);
			}
			else if(state == 2){
				printf("Removing class\n");
				sprintf(query, "delete from AppOn where Class = %i;", appclass);
			}


			mysql_query(con, query);
		}

		mysql_close(con);
	}
}

void MysqlPowerLog (float pavg, unsigned int dt)
{
	MYSQL *con = mysql_init(NULL);

	if(con != NULL){

		if (mysql_real_connect(con, "localhost", "root", "090461", "energymeter", 0, NULL, 0) != NULL)
		{
			// Set out insert query as the MySQL statement
			static char query[1000];

			sprintf(query, "insert into PUnit(Power, Dt) values (%f, %i);", pavg, dt);

			mysql_query(con, query);
		}

		mysql_close(con);
	}
}

void MysqlEnergyLog (float pavg, float energy)
{
	MYSQL *con = mysql_init(NULL);

	if(con != NULL){

		if (mysql_real_connect(con, "localhost", "root", "090461", "energymeter", 0, NULL, 0) != NULL)
		{
			// Set out insert query as the MySQL statement
			static char query[1000];

			sprintf(query, "INSERT INTO energy(dt, pavg, ekwh) VALUES(NOW(), %f, %f)", pavg, energy);

			mysql_query(con, query);
		}

		mysql_close(con);
	}
}

void ProcessEventList(int appclass)
{
	MYSQL *con = mysql_init(NULL);

	if(con != NULL){

		if (mysql_real_connect(con, "localhost", "root", "090461", "energymeter", 0, NULL, 0) != NULL)
		{
			// Set out insert query as the MySQL statement
			static char query[1000];

			printf("Processing energy desaggregation\n");
			sprintf(query, "call spEvaluateEnergy(%i);", appclass);

			mysql_query(con, query);
		}

		mysql_close(con);
	}
}

void MysqlRemoveEvents (void)
{
	MYSQL *con = mysql_init(NULL);

	if(con != NULL){

		if (mysql_real_connect(con, "localhost", "root", "090461", "energymeter", 0, NULL, 0) != NULL)
		{
			// Set out insert query as the MySQL statement
			mysql_query(con, "delete from AppOn;");
			mysql_query(con, "delete from PUnit;");
			mysql_query(con, "delete from PTracker;");
			mysql_query(con, "delete from PBlock;");
		}

		mysql_close(con);
	}
}


void MysqlEndBlock (void)
{
	MYSQL *con = mysql_init(NULL);

	if(con != NULL){

		if (mysql_real_connect(con, "localhost", "root", "090461", "energymeter", 0, NULL, 0) != NULL)
		{
			// Set out insert query as the MySQL statement
			printf("Creating new block\n");
			mysql_query(con, "call spCreateBlock();");
		}

		mysql_close(con);
	}
}
