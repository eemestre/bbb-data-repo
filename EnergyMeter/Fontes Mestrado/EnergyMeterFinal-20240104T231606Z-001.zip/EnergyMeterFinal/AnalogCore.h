/*
 * AnalogCore.h
 *
 *  Created on: May 21, 2017
 *      Author: fernando
 */

#ifndef ANALOGCORE_H_
#define ANALOGCORE_H_

#ifdef __cplusplus
extern "C" {
#endif

#define FS 15360
#define CYCLES 1
#define SAMPLES (FS*CYCLES)

struct tAnalogCoreSetup{
	int bank;
	float * v_channel;
	float * i_channel;
};

int AnalogCore_Init(void);
void AnalogCore_Deinit(void);
int AnalogCore_Setup(struct tAnalogCoreSetup * pAnalog);
int AnalogCore_GetSamples(struct tAnalogCoreSetup * pAnalog);


#ifdef __cplusplus
}
#endif

#endif /* ANALOGCORE_H_ */
