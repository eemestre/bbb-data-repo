/*
 * Flag.c
 *
 *  Created on: Feb 13, 2017
 *      Author: fernando
 */


#include "Flag.h"
#include <pthread.h>

void initialize_flag (struct flag_control * me)
{
	pthread_mutex_init (&me->thread_flag_mutex, NULL);
	me->thread_flag = 0;
}

void set_thread_flag (struct flag_control * me, int flag_value)
{
	/* Protect the flag with a mutex lock.  */
	pthread_mutex_lock (&me->thread_flag_mutex);
	me->thread_flag = flag_value;
	pthread_mutex_unlock (&me->thread_flag_mutex);
}
