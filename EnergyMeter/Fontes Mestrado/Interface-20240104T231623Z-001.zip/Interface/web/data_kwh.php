<?php

header('Content-Type: application/json');

if ($_GET) {
    $argument1 = $_GET['argument1'];
    $argument2 = $_GET['argument2'];
    $argument3 = $_GET['argument3'];



$servername = "localhost";
$username = "root";
$password = "090461";
$dbname = "energymeter";

// Create connection
$con = new mysqli($servername, $username, $password, $dbname);

// Check connection
if (mysqli_connect_errno($con))
{
    echo "Failed to connect to DataBase: " . mysqli_connect_error();
}else
{
    $data_points = array();
    $query = "call spApplianceLog(" . $argument2 . ", " .$argument1 . ", " .$argument3 . ")";
    $result = mysqli_query($con, $query);
    
    while($row = mysqli_fetch_array($result))
    {        
        $point = array("'".$row['class']."'", $row['ekwh']);
        
        array_push($data_points, $point);        
    }
    
    echo json_encode($data_points, JSON_NUMERIC_CHECK);
}
mysqli_close($con);
}

?>
