<?php

header('Content-Type: application/json');

if ($_GET) {
    $argument1 = $_GET['argument1'];
    $argument2 = $_GET['argument2'];
    $argument3 = $_GET['argument3'];



$servername = "localhost";
$username = "root";
$password = "090461";
$dbname = "energymeter";

// Create connection
$con = new mysqli($servername, $username, $password, $dbname);

// Check connection
if (mysqli_connect_errno($con))
{
    echo "Failed to connect to DataBase: " . mysqli_connect_error();
}else
{
    $data_points = array();
    $query = "SELECT Appliance, sum(Duration)/60 as Minutes FROM History where DAY(EventTime) = " . $argument1 . " and MONTH(EventTime) = " .$argument2 . " and Year(EventTime) = " .$argument3 . " group by Appliance";
    $result = mysqli_query($con, $query);
    
    while($row = mysqli_fetch_array($result))
    {        
        $point = array("'".$row['Appliance']."'", $row['Minutes']);
        
        array_push($data_points, $point);        
    }
    
    echo json_encode($data_points, JSON_NUMERIC_CHECK);
}
mysqli_close($con);
}

?>
