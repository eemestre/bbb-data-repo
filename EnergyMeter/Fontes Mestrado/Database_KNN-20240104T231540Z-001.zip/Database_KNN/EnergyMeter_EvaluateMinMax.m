function [ LIMITS ] = EnergyMeter_EvaluateMinMax( DATA )


    LIMITS = zeros(3, 19);
    
    LIMITS(1, :) = min(DATA);
    LIMITS(2, :) = mean(DATA);
    LIMITS(3, :) = max(DATA);

end

