clear all;
close all;

   
PATH_RD = 'C:\Users\Fernando\Google Drive\Mestrado\Database_KNN\';

[DB, ClassName] = EnergyMeter_LoadDatabase2();

MAX_CLASS = size(ClassName,1);

len = size(DB,1);
class = zeros(len,1);


TOTAL = 0;

for i = 1 : 1 : len

    frd = strcat(PATH_RD, char(DB(i,1)), '---', char(DB(i,3)), char(DB(i,2)), '.bin');
    
    if (exist(frd, 'file') == 2)

        fID = fopen(frd, 'r');
        A = fread(fID);
        fclose(fID);    
        TOTAL = TOTAL + size(A,1);
    end
end

COL = 19;
COUNT = 1;
TOTAL = TOTAL/(COL*4);
DATA = zeros(TOTAL, COL+2);

for k = 1 : 1 : len
    
    class(k,1) = str2num(char(DB(k,1)));
    
    frd = strcat(PATH_RD, char(DB(k,1)), '---', char(DB(k,3)), char(DB(k,2)), '.bin');
    
    if (exist(frd, 'file') == 2)
        fID = fopen(frd, 'r');

        A = fread(fID);
        fclose(fID);

        file_idx = 1;
        

        %Faz a leitura do arquivo
        while file_idx < size(A,1)
            for i = 1 : 1 : COL
                idx = file_idx + (i-1)*4;
                DATA(COUNT, 1) = class(k,1);
                DATA(COUNT, 2) = k;
                DATA(COUNT, i+2) = typecast(uint8(A(idx: idx + 3).') , 'single');
            end
            DATA(COUNT, 3) = DATA(COUNT, 3) / 2000;
            COUNT = COUNT + 1;
            file_idx = file_idx + (COL*4);
        end    
    end
end


COUNT = COUNT - 1;


uClusters = unique(class);
nClusters = length(uClusters);
cmap = colorcube(MAX_CLASS);
marker = repmat({'p' 'o' 's' 'd'}, 1, 10);


for i = 1 : 1 : nClusters
    clustIdx = ((DATA(:,1) == uClusters(i)));
    newrows = [DATA(clustIdx, 4) DATA(clustIdx, 3)];
    
    if(i == 1)
        dataset = newrows;
        C = DATA(clustIdx, 1);
    else
        dataset = [dataset; newrows];
        C = [C; DATA(clustIdx, 1)];
    end
end



% Orange-lemons data
training_data = dataset;

% Number of clusters
K = nClusters;

% Concatenate labels to the training data
training_data = cat(2, training_data, C);

% Keep unique number of clusters
tv = unique(C);

% set up the domain over which you want to visualize the decision
% boundary
xrange = [0 1];
yrange = [0 1];
% step size for how finely you want to visualize the decision boundary.
inc = 0.05;
%inc = 0.001;
 
% generate grid coordinates. this will be the basis of the decision
% boundary visualization.
[Xv, Yv] = meshgrid(xrange(1):inc:xrange(2), yrange(1):inc:yrange(2));
% K- nearest neighbours
Knn = 1;
classes = zeros(size(Xv));

% Loop over all test points
for i = 1:length(Xv(:))
    % Get a specific point in 2-D
    point = [Xv(i) Yv(i)];
    % Compute square distance
    dists = square_dist(dataset, point)';
    % Sort distances in ascending order
    [d I] = sort(dists, 'ascend');
    % Classify them using the k-Nearest neighbours
    classes(i) = mode(C(I(1:Knn)));
    
    if classes(i) ~= 1 && classes(i) ~= 2 && classes(i) ~= 19 && classes(i) ~= 20
        classes(i) = 3;
    end
    
    if(i == 1)
       idx = classes(i);
    else
       idx = [idx classes(i)];
    end
end


image_size = size(Xv);
decisionmap = reshape(idx', image_size);
figure;
colormap(cmap);
im = imagesc(xrange,yrange,decisionmap);
im.AlphaData = .5;

hold on;
set(gca,'ydir','normal');

for i = 1 : 1 : nClusters
    
    pos = find(C==uClusters(i));
    cidx = uClusters(i);
    
    if (cidx == 1 || cidx == 2 || cidx == 19 || cidx == 20)
        plot(dataset(pos,1),dataset(pos,2), char(marker(1,cidx)),...
            'MarkerSize',8,...
            'MarkerEdgeColor','k',...
            'MarkerFaceColor',cmap(cidx, :));
    end
    
    hold on;
end

% Draw contour which corresponds to the decision boundaries

title(sprintf('K = %g',Knn));
xlabel('PF');
ylabel('P');

%{
newpoint = [0.65 0.9 0.25 0.3];
plot(newpoint(2),newpoint(1), 'x',...
        'MarkerSize',10,...
        'MarkerEdgeColor','r',...
        'MarkerFaceColor','k');
hold on;   
Mdl = KDTreeSearcher(DATA(:,3:6));

[n,d] = knnsearch(Mdl,newpoint,'k',1);

plot(DATA(n,4),DATA(n,3), 'o',...
        'MarkerSize',10,...
        'MarkerEdgeColor','k',...
        'MarkerFaceColor','r');
%}
%tabulate(DATA(n, 1));
%ClassName(3,:) = {'Outros'};
legend(ClassName([1,2,19,20],:));
xlim([0 1]);
ylim([0 1]);
%contour(Xv, Yv, classes);
