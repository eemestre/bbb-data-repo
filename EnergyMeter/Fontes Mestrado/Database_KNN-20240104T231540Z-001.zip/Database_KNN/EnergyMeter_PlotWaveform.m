function [ ] = EnergyMeter_PlotWaveform( V, I, CYCLES, START )

    figure;
    
    COUNT = size(V,2);

    x = 0 : (1/COUNT) : (((1/COUNT)*CYCLES*256));
    
    if CYCLES == 60
            
        [ax, h1, h2] = plotyy(x(1,1:COUNT),V(1, 1:(COUNT)), x(1,1:COUNT),I(1, 1:COUNT));
        
    else
        Max = (COUNT/60) * CYCLES;
        START = START*256 + 1;
        [ax, h1, h2] = plotyy(x, V(1, START:(START+Max)), x, I(1, START:(START+Max)));  
        xlim(ax(1),[0 inf]);
        xlim(ax(2),[0 inf]);
    end

    set([h1(1)], 'color', 'r');
    set([h2(1)], 'color', 'b');
    set(get(ax(1), 'Ylabel'), 'String', 'Tens�o (V)');
    set(get(ax(2), 'Ylabel'), 'String', 'Corrente (A)');
    set(ax(1),'YColor','r');
    set(ax(2),'YColor','b');
    xlabel('Tempo em segundos');
    title('Oscilograma');

end

