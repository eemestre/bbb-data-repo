function [ ] = EnergyMeter_Plot3( DATA, k, Title, HS, MS, SS, H, M)

    figure;

    COUNT = size(DATA,1);
    xx = linspace(0,COUNT,COUNT);
    plot(xx, DATA(:,k));
    title(Title);
    ylim([0 inf]);        
    xlim([0 COUNT]);    
    
    lbl = zeros(24);
    
    lbl(1: (24-HS)) = num2str((HS : 24));
    
    if(length(Hv) < 24)
        
    end
    
    xticks(0:24);
    datetick('x','HH:MM');
    %xticklabels({'x = 0','x = 5','x = 10'})

end

