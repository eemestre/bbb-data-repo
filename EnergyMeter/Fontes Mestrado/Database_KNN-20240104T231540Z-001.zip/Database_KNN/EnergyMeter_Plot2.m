function [ ] = EnergyMeter_Plot2( DATA, k, Title, Min, Avg, Max )

    figure;
    COUNT = size(DATA,1);
    xx = linspace(0,COUNT,COUNT);
    
    plot(xx, DATA(:,k));
    hold on;
    avg = Min;
    plot([0 COUNT], [avg avg],'r');
    avg = Avg;
    plot([0 COUNT], [avg avg],'r');
    avg = Max;
    plot([0 COUNT], [avg avg],'r');
    hold off;
    
    title(Title);
    ylim([0 inf]);        
    xlim([0 COUNT]);        
end


