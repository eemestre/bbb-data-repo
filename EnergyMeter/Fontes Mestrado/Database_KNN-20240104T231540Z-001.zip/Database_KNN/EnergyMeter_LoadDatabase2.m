function [ DB_ITEMS ClassName] = EnergyMeter_LoadDatabas2e(  )


[DB_ITEMS ClassName] =  EnergyMeter_LoadDatabase();

DB_ITEMS = [ DB_ITEMS
    
    %{ '1', 'Brastemp Duplex Frost-Free BRM47 - C', '24_05_2017'},
    %{ '1', 'Eletrolux Frost-Free DF45 - C', '27_05_2017'},
    %{ '1', 'Consul Facilite Frost-Free - C', '26_05_2017'},
    %{ '1', 'Brastemp Duplex Frost-Free BRM47 - 2 - C', '03_06_2017'},

    { '9', 'Electrolux Front Load LE05_S1', '29_05_2017'},
    { '9', 'Electrolux Front Load LE05_S2', '29_05_2017'},
    { '9', 'Electrolux Front Load LE05_S3', '29_05_2017'},

];

end

