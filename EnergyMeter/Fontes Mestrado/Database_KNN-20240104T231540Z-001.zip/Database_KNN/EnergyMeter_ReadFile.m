function [ DATA, H, M ] = EnergyMeter_ReadFile( path )

    fID = fopen(path, 'r');
    
    A = fread(fID);
    fclose(fID);

    file_idx = 1;
    
    Len = size(A,1);
    COL = 19;
    ROWS = Len/(COL*4);
    COUNT = ROWS;
    
    %alterar o total de amostras para m�ltiplos de 60 segundos
    while (mod(COUNT,60) ~= 0)
        COUNT = COUNT - 1;    
    end
    
    DATA = zeros(ROWS,COL);
    TMP = 1;

    %Faz a leitura do arquivo
    while file_idx < Len
        for i = 1 : 1 : COL
            idx = file_idx + (i-1)*4; 
            DATA(TMP, i) = typecast(uint8(A(idx: idx + 3).') , 'single');
        end

        if DATA(TMP,2) > 1
            DATA(TMP,2) = 1;
        end
        
        if DATA(TMP,3) > 1
            DATA(TMP,3) = 1;
        end
        
        if DATA(TMP,4) > 1
            DATA(TMP,4) = 1;
        end
    
        TMP = TMP + 1;
        file_idx = file_idx + (COL*4);
    end
    
    
    
    H = int32(COUNT/3600);
    M = (COUNT - (H*3600))/60;
    
end

