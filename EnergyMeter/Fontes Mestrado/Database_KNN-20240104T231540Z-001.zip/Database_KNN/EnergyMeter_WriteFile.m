function [ ] = EnergyMeter_WriteFile( path, DATA )

    fileID = fopen(path,'w');
    fwrite(fileID, DATA','single');
    fclose(fileID);

end

