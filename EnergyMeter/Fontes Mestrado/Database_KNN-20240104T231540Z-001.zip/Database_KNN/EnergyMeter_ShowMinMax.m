function [ ] = EnergyMeter_ShowMinMax( DATA_MIN_MAX, Index, Pname )

        for k = 1 : 1 : size(Index,2)    
            str = sprintf('%s: %.3f & %.3f & %.3f\r\n', char(Pname(k,:)), DATA_MIN_MAX(1, Index(k)), DATA_MIN_MAX(2, Index(k)), DATA_MIN_MAX(3, Index(k)));
            disp(str);
        end
end

