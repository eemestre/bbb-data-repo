function [ DATA_AVG ] = EnergyMeter_CalculateAverage( DATA, H, M)


    COL = 19;
    LINES = (H*3600) + M*60;
    M = (H*60)+M;
    
    %buffer para calcular m�dia a cada minuto
    BufferSec = zeros(1, 60);

    DATA_AVG = zeros(M, COL);

    for j = 1 : 1 : COL

        acc_min = 0;
        min = 1;

        for i = 1 : 1 : 60
           BufferSec(1,i) = DATA(i, j);
           acc_min = acc_min + DATA(i, j);
        end

        DATA_AVG(min,j) = acc_min / 60;

        min = min + 1;
        old_value = 1;

        for i = 61 : 1 : LINES
            acc_min = acc_min - BufferSec(1, old_value) + DATA(i, j);
            BufferSec(1, old_value) = DATA(i, j);
            old_value = old_value + 1;

            if old_value == 61
                old_value = 1;
                DATA_AVG(min,j) = acc_min / 60;
                min = min + 1;
            end
        end    
    end


end

