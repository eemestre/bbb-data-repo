function [ DATA_V, DATA_I, OK ] = EnergyMeter_ReadWaveform( path )

    
    fileV = strcat(path, '\V.wvf');
    fileI = strcat(path, '\I.wvf');

    COUNT = 15360;
    DATA_V = zeros(1, COUNT);
    DATA_I = zeros(1, COUNT);
    
    if (exist(fileV, 'file') == 2) && (exist(fileI, 'file') == 2)
            


        fID = fopen(fileV, 'r');

        A = fread(fID);
        fclose(fID);

        file_idx = 1;

        i = 1;
        while i < COUNT

            idx = file_idx + (i-1)*4; 
            DATA_V(1, i) = typecast(uint8(A(idx: idx + 3).') , 'single');
            i = i + 1;
        end


        fID = fopen(fileI, 'r');
        A = fread(fID);
        fclose(fID);

        file_idx = 1;
        i = 1;
        while i < COUNT

            idx = file_idx + (i-1)*4; 
            DATA_I(1, i) = typecast(uint8(A(idx: idx + 3).') , 'single');
            i = i + 1;
        end
        
        OK = 1;
    else
        OK = 0;
        disp('Waveform: Arquivo n�o foi encontrado\n');
    end
end

