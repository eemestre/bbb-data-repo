function [ ] = EnergyMeter_Plot( DATA, k, Title )

    figure;

    COUNT = size(DATA,1);
    xx = linspace(0,COUNT,COUNT);
    plot(xx, DATA(:,k));
    title(Title);
    ylim([0 inf]);        
    xlim([0 COUNT]);        
    
    %{    
    t1 = datetime(2013,11,1,8,0,0);
    t2 = t1 + seconds(size(DATA,1));
    plot(t2, DATA(:,k));

    %datetick('x', 'HH:MM:SS PM', 'keeplimits', 'keepticks');
    xtickformat('hh:mm');
    %}
end

