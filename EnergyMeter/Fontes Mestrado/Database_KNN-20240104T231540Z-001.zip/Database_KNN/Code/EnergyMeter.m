clear all;
close all;

PATH = '..\Raw\';

[DB, ClassName] = EnergyMeter_LoadDatabase();

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Select appliance from database

len = size(DB,1);

for i = 1 : 1 : len
    fprintf('%i: %s\n', i, char(DB(i,2)));
end

selectedItem = input('Eletrodom�stico:');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if selectedItem >= 1 && selectedItem <= len
    
    %Determine which folder will be accessed
    fname = strcat(PATH, char(DB(selectedItem,1)), '\', char(DB(selectedItem,2)),'\DB.bin');
    fwvf = strcat(PATH, char(DB(selectedItem,1)), '\', char(DB(selectedItem,2)));

    
    %Read appliance waveform
    [V, I, OK] = EnergyMeter_ReadWaveform(fwvf);

    if OK == 1
        EnergyMeter_PlotWaveform(V,I,3,30);
        EnergyMeter_PlotWaveform(V,I,59,0);
    end
    
    
    
    %Read DB file of selected item
    [DATA, H, M] = EnergyMeter_ReadFile(fname);
    
    Index = [
        1, 
        2, 
        3, 
        4
    ];

    Titles1 = {'Pot�ncia M�dia (W)'
        'PF'
        'QF'
        'VF'};
    
    for k = 1 : 1 : size(Index,2)
       str = strcat(char(Titles1(k,:)), ' x Segundos');
        EnergyMeter_Plot(DATA, Index(k), str); 
    end
end