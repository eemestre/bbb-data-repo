clear all;
close all;

%%PATH = 'C:\Users\Fernando\Google Drive\Mestrado\Projeto Medidor Cognitivo\Database_KNN\Raw\';
PATH = '.\Raw\';
PATH_WR = 'C:\Users\Fernando\Google Drive\Mestrado\Database_KNN\';

[DB, ClassName] = EnergyMeter_LoadDatabase();

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Select appliance from database

len = size(DB,1);

for i = 1 : 1 : len
    fprintf('%i: %s\n', i, char(DB(i,2)));
end

selectedItem = input('Eletrodom�stico:');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if selectedItem >= 1 && selectedItem <= len
    
    %Determine which folder will be accessed
    fname = strcat(PATH, char(DB(selectedItem,1)), '\', char(DB(selectedItem,2)),'\DB.bin');
    fwvf = strcat(PATH, char(DB(selectedItem,1)), '\', char(DB(selectedItem,2)));
    fwr = strcat(PATH_WR, char(DB(selectedItem,1)), '---', char(DB(selectedItem,3)), char(DB(selectedItem,2)), '.bin');
    
    waveform = 'n';
    write = 'n';
    dft = 'n';
    prd = 'n';
    pmin = inf;
    pmax = inf;
    
    selectedItem = input('Waveform? s/n [s]:', 's');
    
    if selectedItem == 's' || isempty(selectedItem)
        waveform = 's';
    end
    
    selectedItem = input('DFT? s/n [s]:', 's');
    
    if selectedItem == 's' || isempty(selectedItem)
        dft = 's';
    end
    
    selectedItem = input('Intervalo? s/n [s]:', 's');
    
    if selectedItem == 's' || isempty(selectedItem)
        prd = 's';
    end
    
    if waveform == 's'
        %Read appliance waveform
        [V, I, OK] = EnergyMeter_ReadWaveform(fwvf);
        
        if OK == 1
            EnergyMeter_PlotWaveform(V,I,3,30);
            EnergyMeter_PlotWaveform(V,I,59,0);
        end
    end
    
    
    %Read DB file of selected item
    [DATA, H, M] = EnergyMeter_ReadFile(fname);
    

    Index = [
        1, 
        2, 
        3, 
        4
    ];


    Titles1 = {'Pot�ncia M�dia (W)'
        'PF'
        'QF'
        'VF'};
    
    for k = 1 : 1 : size(Index,2)
       str = strcat(char(Titles1(k,:)), ' x Segundos');
        EnergyMeter_Plot(DATA, Index(k), str); 
        
    end
    
    %EnergyMeter_Plot3(DATA, 1, str, 18, 0, 0, 24, 0);
    
    selectedItem = input('Pot�ncia m�nima? [-1]');
    
    if selectedItem ~= -1
        pmin = selectedItem;
    end
    
    selectedItem = input('Pot�ncia m�xima? [-1]');
    
    if selectedItem ~= -1
        pmax = selectedItem;
    end
    
    selectedItem = input('Gerar arquivo? s/n [s]:', 's');
    
    if selectedItem == 's' || isempty(selectedItem)
        write = 's';
    end
    
    if prd == 's'
        t1 = input('T1 (s)? [-1]');
        t2 = input('T2 (s)? [-1]');
        
        while (mod(t2-t1,60) ~= 0)
            t2 = t2 - 1;    
        end
          
        DATA = DATA(t1:t2,:);
        COUNT = size(DATA,1);
        H = int32((t2 - t1)/3600);
        M = (COUNT - (H*3600))/60;
    end

    if (H > 0) || (M >= 30)
        
        %Calculate average value of each parameter by minute
        [DATA_AVG] = EnergyMeter_CalculateAverage(DATA, H, M);
         
        EnergyMeter_Plot(DATA_AVG, 1, 'Pot�ncia M�dia (W) x Minutos');

        %Select data using threshold values of active power
        [DATA_FILTERED] = EnergyMeter_ApplyFilter(DATA_AVG, pmin, pmax);

        %Plot filtered data
        EnergyMeter_PlotCurrentDFT(DATA_FILTERED);
        
        %Evaluate Min, Avg, and Max values of parameters
        [DATA_MIN_MAX] = EnergyMeter_EvaluateMinMax(DATA_FILTERED);
        
        
        for k = 1 : 1 : size(Index,1)    
            str = strcat(char(Titles1(k,:)), ' x Minutos');
            EnergyMeter_Plot2(DATA_FILTERED, Index(k), str, ...
                DATA_MIN_MAX(1, Index(k)),... 
                DATA_MIN_MAX(2, Index(k)),...
                DATA_MIN_MAX(3, Index(k)));    
        end
        
        EnergyMeter_Plot(DATA_FILTERED, 1, char(Titles1(1,:)));
        
        if write == 's'
            EnergyMeter_WriteFile(fwr, DATA_FILTERED);
        end
    else

        %Select data using threshold values of active power
        [DATA_FILTERED] = EnergyMeter_ApplyFilter(DATA, pmin, pmax);
        
        %Plot filtered data
        EnergyMeter_PlotCurrentDFT(DATA_FILTERED);
        
        [DATA_MIN_MAX] = EnergyMeter_EvaluateMinMax(DATA_FILTERED);
        
        for k = 1 : 1 : size(Index,2)    
            EnergyMeter_Plot2(DATA_FILTERED, Index(k), char(Titles1(k,:)), ...
                DATA_MIN_MAX(1, Index(k)),... 
                DATA_MIN_MAX(2, Index(k)),...
                DATA_MIN_MAX(3, Index(k)));    
        end
        EnergyMeter_Plot(DATA_FILTERED, 1, char(Titles1(1,:)));
        
        if write == 's'
            EnergyMeter_WriteFile(fwr, DATA_FILTERED);
        end
    end
    
    EnergyMeter_ShowMinMax(DATA_MIN_MAX, Index', Titles1);
end