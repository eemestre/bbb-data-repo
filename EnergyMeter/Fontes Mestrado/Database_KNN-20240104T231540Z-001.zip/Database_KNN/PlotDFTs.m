clear all;
close all;

PATH = 'C:\Users\Fernando\Google Drive\Mestrado\Database_KNN\Raw\';
PATH_WR = 'C:\Users\Fernando\Google Drive\Mestrado\Database_KNN\';

[DB, ClassName] = EnergyMeter_LoadDatabase();

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Select appliance from database

len = size(DB,1);

for i = 1 : 1 : len
    fprintf('%i: %s\n', i, char(DB(i,2)));
end

selectedItem = input('Eletrodom�stico:');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if selectedItem >= 1 && selectedItem <= len
    
    %Determine which folder will be accessed
    fname = strcat(PATH, char(DB(selectedItem,1)), '\', char(DB(selectedItem,2)),'\DB.bin');
    fwvf = strcat(PATH, char(DB(selectedItem,1)), '\', char(DB(selectedItem,2)));
    fwr = strcat(PATH_WR, char(DB(selectedItem,1)), '---', char(DB(selectedItem,3)), char(DB(selectedItem,2)), '.bin');
    
    waveform = 's';
    
    dft = 's';
    
    if waveform == 's'
        %Read appliance waveform
        [V, I, OK] = EnergyMeter_ReadWaveform(fwvf);
        
        if OK == 1
            EnergyMeter_PlotWaveform(V,I,3,30);
            EnergyMeter_PlotWaveform(V,I,59,0);
        end
    end
    
    %Read DB file of selected item
    [DATA, H, M] = EnergyMeter_ReadFile(fname);

    %Select data using threshold values of active power
    [DATA_FILTERED] = EnergyMeter_ApplyFilter(DATA, 120, 150);

    %Plot filtered data
    EnergyMeter_PlotCurrentDFT(DATA_FILTERED);

end
  
