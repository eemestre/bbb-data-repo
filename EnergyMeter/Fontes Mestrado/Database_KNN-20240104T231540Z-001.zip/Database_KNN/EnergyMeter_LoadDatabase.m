function [ DB_ITEMS ClassName] = EnergyMeter_LoadDatabase(  )


DB_ITEMS = [
    
    %%Classe 1: Geladeiras
    { '1', 'Brastemp Duplex Frost-Free', '24_05_2017'},
    { '1', 'Brastemp Duplex Frost-Free BRM47', '24_05_2017'},
    { '1', 'Eletrolux Frost-Free DF45', '27_05_2017'},
    { '1', 'Consul Facilite Frost-Free', '26_05_2017'},
    %{ '1', 'Brastemp Duplex Frost-Free BRM47 - 2', '03_06_2017'},
    %{ '1', 'Brastemp Duplex Frost-Free', '06_06_2017'},%%%%%%Bogila
    { '1', 'Brastemp Duplex Frost-Free BRM49', '21_12_2017'},
    { '1', 'Brastemp Duplex Frost-Free BRM49 - 2', '21_12_2017'},
    
    
    %%Classe 2: Microondas
    { '2', 'Panasonic FlatStyle 1', '31_05_2017'},
    { '2', 'Panasonic FlatStyle 3', '31_05_2017'},
    { '2', 'Panasonic FlatStyle 5', '31_05_2017'},
    { '2', 'Brastemp', '06_06_2017'}, %%%%%%Bogila
    
    { '3', 'Purificador IBBL', '06_06_2017'}, %%%%%%Bogila
    
    %%Classe 4: Notebook
    { '4', 'Dell Vostro P24F - Charging', '27_05_2017'},
    { '4', 'Dell Inspiron 14R - Charging', '29_05_2017'},
    { '4', 'HP Compaq Presario CQ50-113BR', '30_05_2017'},
    { '4', 'Lenovo LNV L1325', '30_05_2017'},

    %%Classe 5: Aparelho de som
    { '5', 'Mini System Philco PH400', '29_05_2017'},
    { '5', 'Micro HI-FI Component CMT-HP7', '03_06_2017'},
    
    %%Classe 6: 
    { '6', 'Samsung 40 polegadas', '06_06_2017'}, %%%%%%Bogila
    { '6', 'Samsung 50 polegadas', '06_06_2017'}, %%%%%%Bogila
    
    %%Classe 7: Liquidificador
    { '7', 'Arno MagicClean 1', '31_05_2017'},
    { '7', 'Arno MagicClean 5', '31_05_2017'},

    %%Classe 8: Televis�o LCD
    { '8', 'Samsung LCD 42 polegadas', '24_05_2017'},
    { '8', 'Samsung LCD 26 polegadas D450', '27_05_2017'},
    { '8', 'LG 32LC3R LCD 32 polegadas', '27_05_2017'},
    
    %%Classe 9: M�quina de Lavar Roupa
    { '9', 'Electrolux Front Load LE05', '29_05_2017'},
    { '9', 'Electrolux Front Load LE051', '29_05_2017'},
    { '9', 'Electrolux Front Load LE052', '29_05_2017'},
    
    { '10', 'Secador de cabelo DAIHATSU 1', '31_05_2017'},
    { '10', 'Secador de cabelo DAIHATSU 2', '31_05_2017'},
    { '10', 'Secador de cabelo TAIFF 1', '05_06_2017'},
    { '10', 'Secador de cabelo TAIFF 2', '05_06_2017'},
    
    %%Classe 11: L�mpada Fluorescente
    { '11', 'L�mpada Fluorescente Compacta 20W', '30_05_2017'},
    { '11', 'L�mpada Fluorescente Compacta 23W', '05_06_2017'},
    

    %%Classe 12: Computador Desktop
    { '12', 'Dell OptiPlex 745', '30_05_2017'},
    { '12', 'Dell OptiPlex 170L', '31_05_2017'},
    
    %%Classe 13: Forno El�trico
    { '13', 'Arno Miniforno Super Chef', '30_05_2017'},
    
    %%Classe 14: Monitor LCD
    { '14', 'Monitor LCD Hyundai', '29_05_2017'},
    { '14', 'Monitor LCD  E178pc 19 polegadas', '30_05_2017'},
    { '14', 'Monitor Tubo Dell E773C', '31_05_2017'},
    { '14', 'Samsumg LT19B300 19 polegadas', '26_05_2017'},
    
    %%Classe 15: L�mpada LED
    { '15', 'L�mpada LED Philiphis 8.5W', '05_06_2017'},

    %%Classe 16: Ferro de passar roupa
    { '16', 'Black & Decker X300', '31_05_2017'},
    
    %%Classe 17: L�mpada Incandescente 40W
    { '17', 'L�mpada Incandescente 40W', '30_05_2017'},
    { '17', 'L�mpada Incandescente 100W', '05_06_2017'},
    
    
    %%Classe 18: Fritadeira El�trica
    { '18', 'Mondial Air Fryer 1', '30_05_2017'},
    { '18', 'Mondial Air Fryer 2', '30_05_2017'},
    
    %%Classe 19: Ar condicionado
    { '19', 'DeLonghi 1', '18_06_2017'},
    { '19', 'DeLonghi 2', '19_06_2017'},
    { '19', 'DeLonghi 3', '19_06_2017'},
    { '19', 'Consul', '6_11_2017'},
    
    { '20', 'Brastemp Duplex Frost-Free BRM47 Degelo', '24_05_2017'}
    { '20', 'Eletrolux Frost-Free DF45 Degelo', '27_05_2017'}
    { '20', 'Consul Facilite Frost-Free Degelo', '26_05_2017'}
    %{ '20', 'Brastemp Duplex Frost-Free BRM47 - 2 Degelo', '03_06_2017'},
    %{ '20', 'Brastemp Duplex Frost-Free Degelo', '06_06_2017'},%%%%%%Bogila
    { '20', 'Brastemp Duplex Frost-Free BRM49 Degelo', '21_12_2017'},
    
    
    { '21', 'Hitachi Inverter', '20_10_2017'}
];

ClassName = {
	'Classe 1: Geladeira (compressor).',
	'Classe 2: Micro-ondas.',
	'Classe 3: Purificador de �gua.',
	'Classe 4: Notebook.',
	'Classe 5: Aparelho de som.',
	'Classe 6: Televis�o LED.',
	'Classe 7: Liquidificador.',
	'Classe 8: Televis�o LCD.',
	'Classe 9: M�quina de lavar roupas.',
	'Classe 10: Secador de cabelos.',
	'Classe 11: L�mpada Fluorescente.',
	'Classe 12: Computador Desktop.',
	'Classe 13: Forno El�trico.',
	'Classe 14: Monitor LCD-LED-Tubo.',
	'Classe 15: L�mpada LED.',
	'Classe 16: Ferro de passar.',
	'Classe 17: L�mpada Incandescente.',
	'Classe 18: Fritadeira El�trica.',
    'Classe 19: Ar condicionado port�til.',
    'Classe 20: Geladeira (Degelo).',
    'Classe 21: Ar condicionado split inverter.',
};

end

