function [ DATA_FILTERED ] = EnergyMeter_ApplyFilter( DATA, P_min, P_max)

    if (P_min ~= inf) & (P_max ~= inf)
        Idx = find((DATA(:, 1) >= P_min) & (DATA(:, 1) <= P_max));
    else
        
        if (P_min ~= inf)
            Idx = find((DATA(:, 1) >= P_min));
        else
            
            if (P_max ~= inf)
                Idx = find((DATA(:, 1) <= P_max));
            else
                DATA_FILTERED = DATA;
                return;
            end
        end
    end

    DATA_FILTERED = DATA(Idx, :);
end

