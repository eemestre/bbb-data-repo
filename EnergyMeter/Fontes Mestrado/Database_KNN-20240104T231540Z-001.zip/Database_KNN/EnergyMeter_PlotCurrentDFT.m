function [ ] = EnergyMeter_PlotCurrentDFT( DATA )

figure;
AvgHarmonics = mean(DATA(:, 6:15),1);
barColorMap = winter(10); 
handleToThisBarSeries = zeros(10);
c = {'H1'; 'H3'; 'H5'; 'H7'; 'H9'; 'H11'; 'H13'; 'H15'; 'H17'; 'H19'};

for b = 1 : 10
    % Plot one single bar as a separate bar series.
    handleToThisBarSeries(b) = bar(b, AvgHarmonics(b), 'BarWidth', 0.9);
    set(handleToThisBarSeries(b), 'FaceColor', barColorMap(1,:));
    hold on;
end

fontSize = 30;
title('Harm�nicas de corrente - componentes �mpares', 'FontSize', 25);
xlabel('Componentes Harm�nicas', 'FontSize', 25);
ylabel('Corrente Harm�nica (A), Valor Eficaz', 'FontSize', 25);
set(gca, 'XTickLabel',c, 'XTick',1:numel(c))
set(gcf, 'units','normalized','outerposition',[0 0 1 1]);
%legend('H1 - 60 Hz', 'H3 - 180 Hz', 'H5 - 300 Hz', 'H7 - 420 Hz', 'H9 - 540 Hz', 'H11 - 660 Hz', 'H13 - 900 Hz', 'H15 - 1020 Hz', 'H17 - 1140 Hz', 'H19 - 1260 Hz');
set(gca, 'FontSize', 20)
end

